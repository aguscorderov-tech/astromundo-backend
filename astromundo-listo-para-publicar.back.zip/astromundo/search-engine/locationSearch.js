// /search-engine/locationSearch.js
// Envuelve geocodeSearch() con debounce, para no golpear la API en cada tecla.
// SearchBox.js (componente) llama a esto, no a geocoding.js directamente —
// así el criterio de "cuándo buscar" queda separado del "cómo se ve".

import { geocodeSearch } from "./geocoding.js";

let debounceTimer = null;
const DEBOUNCE_MS = 300;

/**
 * Busca lugares con debounce. onResults(results) se llama cuando llega la
 * respuesta; onError(err) si falla. Devuelve la query pedida junto con el
 * resultado para que quien la llama pueda descartar respuestas "viejas" si
 * el usuario ya siguió tipeando.
 */
export function searchLocationsDebounced(query, { onResults, onError }) {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(async () => {
    try {
      const results = await geocodeSearch(query);
      onResults(results, query);
    } catch (err) {
      if (err.name === "AbortError") return;
      onError(err, query);
    }
  }, DEBOUNCE_MS);
}
