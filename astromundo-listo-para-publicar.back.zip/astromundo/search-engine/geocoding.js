// /search-engine/geocoding.js
// Consulta el geocoding mundial. No sabe nada de formularios ni de DOM —
// recibe un texto de búsqueda y devuelve datos. La UI (SearchBox.js) es quien
// decide cuándo llamar y qué hacer con el resultado.

import { buildGeocodeUrl } from "./apiConnections.js";
import { getCached, setCached } from "./database.js";

let abortController = null;

// Saca acentos y pasa a minúsculas, para que "cordoba" encuentre "Córdoba".
export function normalizeQuery(s) {
  return s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
}

export async function geocodeSearch(query) {
  const key = normalizeQuery(query);
  const cached = getCached(key);
  if (cached) return cached;

  if (abortController) abortController.abort();
  abortController = new AbortController();

  const res = await fetch(buildGeocodeUrl(query), { signal: abortController.signal });
  if (!res.ok) throw new Error("geocoding-api respondió " + res.status);
  const data = await res.json();

  const results = (data.results || []).map(r => {
    const parts = [r.name];
    if (r.admin1 && r.admin1 !== r.name) parts.push(r.admin1);
    parts.push(r.country);
    return {
      name: parts.join(", "),
      lat: r.latitude, lng: r.longitude,
      elevation: r.elevation,
      tzName: r.timezone,
      tz: null, // se completa al elegir (ver displayOffset) — solo informativo, no se usa para calcular
      population: r.population || 0
    };
  });

  setCached(key, results);
  return results;
}

// Offset de referencia para mostrar en la UI (ej. "UTC-3") — el cálculo real
// de la carta usa astrology-engine/time.js con la fecha exacta de nacimiento,
// esto es solo para que la persona confirme visualmente que eligió bien.
export function displayOffset(tzName) {
  try {
    const dtf = new Intl.DateTimeFormat("en-US", { timeZone: tzName, timeZoneName: "shortOffset" });
    const part = dtf.formatToParts(new Date()).find(p => p.type === "timeZoneName");
    return part ? part.value.replace("GMT", "UTC") : tzName;
  } catch (e) {
    return tzName;
  }
}
