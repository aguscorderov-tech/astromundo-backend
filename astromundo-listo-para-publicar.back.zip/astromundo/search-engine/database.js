// /search-engine/database.js
// Hoy esto es una caché en memoria (se pierde al recargar la página) — es un
// stub intencional para el día que haya backend real. La interfaz (get/set)
// ya está pensada para que ese cambio no obligue a tocar geocoding.js:
// bastaría con reemplazar esta implementación por, por ejemplo, IndexedDB en
// el cliente o una tabla `place_cache` en el backend.

const store = new Map();

export function getCached(key) {
  return store.has(key) ? store.get(key) : null;
}

export function setCached(key, value) {
  store.set(key, value);
}
