// /search-engine/apiConnections.js
// Endpoints externos que usa el buscador de lugares. Separado de la lógica
// para que cambiar de proveedor sea editar una URL, no reescribir geocoding.js.

export const GEOCODING_API = {
  // Open-Meteo Geocoding API — construida sobre GeoNames, gratuita, sin API key,
  // CORS habilitado. Devuelve ciudad/provincia/país/lat/lng/elevación/timezone
  // IANA en una sola consulta. https://open-meteo.com/en/docs/geocoding-api
  baseUrl: "https://geocoding-api.open-meteo.com/v1/search",
  resultCount: 8,
  language: "es",
};

export function buildGeocodeUrl(query) {
  return `${GEOCODING_API.baseUrl}?name=${encodeURIComponent(query)}&count=${GEOCODING_API.resultCount}&language=${GEOCODING_API.language}&format=json`;
}
