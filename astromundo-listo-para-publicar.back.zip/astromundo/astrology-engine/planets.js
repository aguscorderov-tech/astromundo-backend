// /astrology-engine/planets.js
// Datos por planeta que usa tanto el cálculo (SPEED_TABLE) como la presentación
// (colores/glifos) — se agrupan acá porque describen "qué es cada planeta",
// no "cómo se dibuja" (eso lo decide el componente que los consume).

export const PLANET_COLOR = {
  sun:"#D9A93B", moon:"#8FA6B8", mercury:"#C97A3D", venus:"#5FA35F", mars:"#B3462C",
  jupiter:"#5C4B8A", saturn:"#4A3B2A", uranus:"#3FA9C9", neptune:"#2E6E7E", pluto:"#6B1F1F",
  chiron:"#7A8B99"
};
export const PLANET_GLYPH = { sun:"☉",moon:"☽",mercury:"☿",venus:"♀",mars:"♂",jupiter:"♃",saturn:"♄",uranus:"♅",neptune:"♆",pluto:"♇" };

export const PLANET_KEYWORD = {
  sun:"identidad", moon:"emoción", mercury:"pensamiento", venus:"vínculo", mars:"acción",
  jupiter:"expansión", saturn:"estructura", uranus:"cambio", neptune:"disolución", pluto:"poder",
  chiron:"herida", pholus:"detonante", nessus:"patrón repetido", eros:"deseo", eris:"disrupción", chariklo:"cuidado"
};

// Velocidad media diaria (°/día) — se usa como referencia para cuerpos menores
// (los planetas clásicos usan su velocidad real calculada, ver ephemeris.js).
export const SPEED_TABLE = {
  sun:1.0, moon:13.2, mercury:1.4, venus:1.2, mars:0.5,
  jupiter:0.08, saturn:0.03, uranus:0.012, neptune:0.006, pluto:0.004,
  chiron:0.02, pholus:0.015, nessus:0.01, eros:0.2, eris:0.002, chariklo:0.015
};

// Nombre del cuerpo tal como lo espera astronomy-engine (Body enum) para cada planeta real.
export const REAL_BODY_MAP = { mercury:"Mercury", venus:"Venus", mars:"Mars", jupiter:"Jupiter", saturn:"Saturn", uranus:"Uranus", neptune:"Neptune", pluto:"Pluto" };

// [clave interna, glifo/código a mostrar, nombre completo] para los 6 cuerpos menores.
export const MINOR_ORDER = [
  ["chiron","⚷","Quirón"], ["pholus","Ph","Folo"], ["nessus","Ns","Neso"],
  ["eros","Er","Eros"], ["eris","Xr","Eris"], ["chariklo","Ca","Chariklo"]
];
