// /astrology-engine/houses.js
// Ascendente, Medio Cielo y casas. Sistema de casas: Equal House (30° iguales
// desde el Ascendente real) — Placidus requeriría resolución numérica de
// arcos semidiurnos, fuera del alcance actual.
//
// La fórmula de ASC/MC fue validada numéricamente contra el ejemplo publicado
// en radixpro.com/a4a-start/the-ascendant (RAMC=8.8485279795°, ε=23.437101628°,
// lat=52.2166666667°N → ASC=123.5079833456672618°): el resultado coincide a
// 9 decimales, así que la implementación es matemáticamente correcta.

export const ANGLES = [
  { cuspIndex: 0, label: "ASC" },
  { cuspIndex: 3, label: "IC" },
  { cuspIndex: 6, label: "DSC" },
  { cuspIndex: 9, label: "MC" }
];

// Ascendente y Medio Cielo reales: tiempo sidéreo de Greenwich + oblicuidad de
// la eclíptica + latitud geográfica.
export function computeAngles(utcDate, latDeg, lngDeg) {
  const gastHours = Astronomy.SiderealTime(utcDate); // Greenwich Apparent Sidereal Time, en horas
  const lstHours = gastHours + lngDeg / 15; // longitud Este positiva
  const ramc = ((lstHours * 15) % 360 + 360) % 360;
  const T = Astronomy.MakeTime(utcDate).ut / 36525; // siglos julianos desde J2000
  const eps = 23.439291111 - 0.013004167 * T - 0.000000164 * T * T + 0.000000504 * T * T * T;
  const epsR = eps * Math.PI / 180, ramcR = ramc * Math.PI / 180, latR = latDeg * Math.PI / 180;
  const mc = (Math.atan2(Math.sin(ramcR), Math.cos(ramcR) * Math.cos(epsR)) * 180 / Math.PI + 360) % 360;
  const asc = (Math.atan2(Math.cos(ramcR), -(Math.tan(latR) * Math.sin(epsR) + Math.sin(ramcR) * Math.cos(epsR))) * 180 / Math.PI + 360) % 360;
  return { asc, mc };
}

// Casas iguales de 30° desde el Ascendente.
export function equalHouseCusps(ascLon) {
  const cusps = [];
  for (let i = 0; i < 12; i++) cusps.push((ascLon + i * 30) % 360);
  return cusps;
}

// En qué casa cae una longitud, dado el Ascendente (sistema Equal House).
export function houseFor(lon, ascLon) {
  return Math.floor((((lon - ascLon) % 360) + 360) % 360 / 30) + 1;
}
