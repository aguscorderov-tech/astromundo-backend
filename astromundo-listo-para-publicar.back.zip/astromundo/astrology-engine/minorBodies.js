// /astrology-engine/minorBodies.js
// Posiciones reales de asteroides y centauros por propagación kepleriana de
// dos cuerpos — astronomy-engine no los cubre, así que se calculan acá con
// los elementos orbitales osculantes publicados por el JPL Small-Body Database.
// No incluye perturbaciones planetarias (a diferencia de Swiss Ephemeris), así
// que hay una deriva pequeña cuanto más lejos del epoch de cada elemento.

// a = semieje mayor (UA), e = excentricidad, i = inclinación, om = long. nodo ascendente,
// w = argumento del perihelio, M0 = anomalía media en "epochJD" (grados salvo a).
const MINOR_ELEMENTS = {
  chiron:   { a:13.70,  e:0.3772, i:6.93,   om:209.38, w:339.48, M0:13.18,  epochJD:2451545.0, periodDays:50.71*365.25 },
  pholus:   { a:20.29,  e:0.5728, i:24.69,  om:119.36, w:354.61, M0:126.19, epochJD:2460200.5, periodDays:33400 },
  nessus:   { a:24.60,  e:0.5153, i:15.62,  om:31.39,  w:170.67, M0:93.62,  epochJD:2460200.5, periodDays:44600 },
  eros:     { a:1.4579, e:0.2226, i:10.828, om:304.32, w:178.82, M0:71.280, epochJD:2458000.5, periodDays:643 },
  eris:     { a:68.15,  e:0.4323, i:43.74,  om:36.08,  w:150.87, M0:209.4,  epochJD:2460200.5, periodDays:206000 },
  chariklo: { a:15.79,  e:0.1678, i:23.39,  om:300.45, w:241.99, M0:113.69, epochJD:2460200.5, periodDays:22900 }
};

function solveKepler(Mrad, e) {
  let E = Mrad;
  for (let k = 0; k < 30; k++) E = E - (E - e * Math.sin(E) - Mrad) / (1 - e * Math.cos(E));
  return E;
}

// Posición heliocéntrica eclíptica (UA) de un cuerpo menor en un instante dado.
function minorBodyHelioEcliptic(key, utcDate) {
  const el = MINOR_ELEMENTS[key];
  const utNow = Astronomy.MakeTime(utcDate).ut;
  const epochUT = el.epochJD - 2451545.0;
  const n = 360 / el.periodDays;
  let M = (el.M0 + n * (utNow - epochUT)) % 360;
  if (M < 0) M += 360;
  const E = solveKepler(M * Math.PI / 180, el.e);
  const xOrb = el.a * (Math.cos(E) - el.e);
  const yOrb = el.a * Math.sqrt(1 - el.e * el.e) * Math.sin(E);
  const omR = el.om * Math.PI / 180, wR = el.w * Math.PI / 180, iR = el.i * Math.PI / 180;
  const cosO = Math.cos(omR), sinO = Math.sin(omR), cosW = Math.cos(wR), sinW = Math.sin(wR), cosI = Math.cos(iR), sinI = Math.sin(iR);
  return {
    x: (cosO*cosW - sinO*sinW*cosI)*xOrb + (-cosO*sinW - sinO*cosW*cosI)*yOrb,
    y: (sinO*cosW + cosO*sinW*cosI)*xOrb + (-sinO*sinW + cosO*cosW*cosI)*yOrb,
    z: (sinW*sinI)*xOrb + (cosW*sinI)*yOrb
  };
}

// Longitud eclíptica GEOcéntrica: resta la posición heliocéntrica de la Tierra
// (vía astronomy-engine) a la del cuerpo menor.
export function minorBodyGeoLongitude(key, utcDate) {
  const body = minorBodyHelioEcliptic(key, utcDate);
  const earthHelioEQJ = Astronomy.HelioVector("Earth", utcDate);
  const earthEcl = Astronomy.Ecliptic(earthHelioEQJ).vec;
  const gx = body.x - earthEcl.x, gy = body.y - earthEcl.y;
  let lon = Math.atan2(gy, gx) * 180 / Math.PI;
  return lon < 0 ? lon + 360 : lon;
}
