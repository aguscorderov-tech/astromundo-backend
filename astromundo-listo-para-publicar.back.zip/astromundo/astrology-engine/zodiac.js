// /astrology-engine/zodiac.js
// Todo lo referido a signos, elementos y decanatos. Sin DOM, sin estado — funciones puras.

export const SIGN_NAMES_ES = ["Aries","Tauro","Géminis","Cáncer","Leo","Virgo","Libra","Escorpio","Sagitario","Capricornio","Acuario","Piscis"];
export const ZODIAC_SIGNS = ["♈","♉","♊","♋","♌","♍","♎","♏","♐","♑","♒","♓"];
export const ZODIAC_ELEMENTS = ["fire","earth","air","water","fire","earth","air","water","fire","earth","air","water"];
export const ELEMENT_COLOR = { fire:"#B3462C", earth:"#B8863B", air:"#3C6E9E", water:"#0F5C5C" };

// Regentes de decanato — sistema caldeo clásico (ver nota completa en la vista de carta natal).
export const DECAN_RULERS = [["♂","☉","♀"],["☿","☽","♄"],["♃","♂","☉"],["♀","☿","☽"],["♄","♃","♂"],["☉","♀","☿"],["☽","♄","♃"],["♂","☉","♀"],["☿","☽","♄"],["♃","♂","☉"],["♀","☿","☽"],["♄","♃","♂"]];
export const RULER_NAME = { "♂":"Marte","☉":"Sol","♀":"Venus","☿":"Mercurio","☽":"Luna","♄":"Saturno","♃":"Júpiter" };

export function signIndex(lon) {
  return Math.floor(((lon % 360) + 360) % 360 / 30);
}

export function getDecan(lon) {
  const s = signIndex(lon);
  const dIn = ((lon % 360) + 360) % 360 - s * 30;
  const num = Math.floor(dIn / 10) + 1;
  const ruler = DECAN_RULERS[s][num - 1];
  const start = (num - 1) * 10;
  return { signIdx: s, decanNum: num, ruler, rangeStart: start, rangeEnd: start + 10 };
}

// Elemento predominante entre los planetas principales de una carta (cuerpos
// menores excluidos a propósito, para que no distorsionen la lectura clásica).
export function dominantElement(positions) {
  const counts = { fire: 0, earth: 0, air: 0, water: 0 };
  Object.values(positions).forEach(d => { if (!d.minor) counts[ZODIAC_ELEMENTS[signIndex(d.lon)]]++; });
  return Object.entries(counts).sort((a, b) => b[1] - a[1])[0][0];
}
