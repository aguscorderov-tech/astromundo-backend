// /astrology-engine/time.js
// Todo lo que tiene que ver con "convertir la hora que dio el cliente en la
// hora astronómica que necesita el cálculo". Es la parte que más silenciosamente
// rompe la precisión de una carta si se hace mal (huso horario histórico).

// Resuelve hora civil + zona IANA ("America/Argentina/Buenos_Aires") a UTC real,
// respetando el horario de verano vigente en la FECHA exacta (no el actual) —
// usa la base de husos horarios del propio navegador vía Intl.
export function resolveUTCFromLocal(dateStr, timeStr, tzName) {
  const [y, m, d] = dateStr.split("-").map(Number);
  const [hh, mm] = (timeStr || "12:00").split(":").map(Number);
  let guess = Date.UTC(y, m - 1, d, hh, mm);
  try {
    const dtf = new Intl.DateTimeFormat("en-US", {
      timeZone: tzName, hourCycle: "h23",
      year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit"
    });
    for (let iter = 0; iter < 2; iter++) {
      const parts = {};
      dtf.formatToParts(new Date(guess)).forEach(p => { parts[p.type] = p.value; });
      const localAsUTC = Date.UTC(+parts.year, +parts.month - 1, +parts.day, +parts.hour, +parts.minute, +parts.second);
      const diff = localAsUTC - guess;
      guess = guess - diff;
    }
  } catch (e) {
    console.warn("No se pudo resolver el huso horario IANA (" + tzName + "), se usa el offset fijo como respaldo.", e);
  }
  return new Date(guess);
}

// Respaldo: convierte con un offset fijo tipo "UTC-3" — solo se usa si no hay
// nombre de zona IANA disponible (ej. coordenadas cargadas a mano).
export function toUTCDate(dateStr, timeStr, tzStr) {
  const [y, m, d] = dateStr.split("-").map(Number);
  const [hh, mm] = (timeStr || "12:00").split(":").map(Number);
  const match = /UTC([+-])(\d+)(?::(\d+))?/.exec(tzStr || "UTC+0");
  let offsetHours = 0;
  if (match) offsetHours = (match[1] === "-" ? -1 : 1) * (parseInt(match[2], 10) + (match[3] ? parseInt(match[3], 10) / 60 : 0));
  return new Date(Date.UTC(y, m - 1, d, hh, mm) - offsetHours * 3600000);
}

// Punto de entrada único: usa zona IANA si está disponible, si no cae al offset fijo.
export function resolveBirthUTC({ date, time, timeUnknown, tz, tzName }) {
  const effectiveTime = timeUnknown ? "12:00" : time; // convención: sin hora, se usa el mediodía
  return tzName
    ? resolveUTCFromLocal(date, effectiveTime, tzName)
    : toUTCDate(date, effectiveTime, tz);
}
