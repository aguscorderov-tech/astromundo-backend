// /astrology-engine/calculations.js
// Punto de entrada único del motor de cálculo. Combina ephemeris + minorBodies
// + houses + aspects + zodiac en un solo resultado: la carta calculada.
// No conoce clientes, ni turnos, ni nada de negocio — recibe los datos de
// nacimiento que necesita y devuelve números. La orquestación con el resto
// de la app vive en /services/natalChartService.js.

import { hasRealEphemeris, eclipticLongitude, realDailySpeed, fallbackSunLongitude } from "./ephemeris.js";
import { minorBodyGeoLongitude } from "./minorBodies.js";
import { computeAngles, equalHouseCusps, houseFor } from "./houses.js";
import { calculateAllAspects } from "./aspects.js";
import { SIGN_NAMES_ES, signIndex } from "./zodiac.js";
import { PLANET_GLYPH, MINOR_ORDER, SPEED_TABLE } from "./planets.js";
import { resolveBirthUTC } from "./time.js";

const REAL_PLANET_KEYS = ["sun","moon","mercury","venus","mars","jupiter","saturn","uranus","neptune","pluto"];

// Generador determinístico simple (mismo input siempre da la misma carta) —
// solo se usa como respaldo si astronomy-engine no cargó.
function seedFromString(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
  return () => { h ^= h << 13; h ^= h >>> 17; h ^= h << 5; return ((h >>> 0) / 4294967295); };
}

/**
 * Calcula una carta natal completa.
 * @param {object} birthData - { date, time, timeUnknown, place, lat, lng, tz, tzName, name, id }
 * @param {string} chartId - id ya asignado por el servicio que llama (natalChartService)
 * @returns {object} carta calculada: positions, houseCusps, aspects, ascLon, mcLon, housesReliable, engine
 */
export function generateChart(birthData, chartId) {
  const timeUnknown = !!birthData.timeUnknown || !birthData.time;
  const seed = seedFromString(birthData.date + "|" + birthData.time + "|" + birthData.place + "|" + birthData.name + "|" + birthData.id);
  const utcDate = resolveBirthUTC(birthData);
  const realEphemeris = hasRealEphemeris();
  const positions = {};

  if (realEphemeris && birthData.date) {
    REAL_PLANET_KEYS.forEach(name => {
      const speed = realDailySpeed(name, utcDate);
      positions[name] = { lon: eclipticLongitude(name, utcDate), retrograde: speed < 0, speed };
    });
  } else {
    positions.sun = { lon: fallbackSunLongitude(birthData.date), retrograde: false, speed: 1.0 };
    REAL_PLANET_KEYS.slice(1).forEach(name => {
      const retro = seed() < 0.15;
      positions[name] = { lon: seed() * 360, retrograde: retro, speed: (SPEED_TABLE[name] || 0.5) * (retro ? -1 : 1) };
    });
  }

  // Cuerpos menores: posición real por elementos orbitales del JPL SBDB + propagación kepleriana.
  MINOR_ORDER.forEach(([name, glyph, fullName]) => {
    if (realEphemeris) {
      const lon1 = minorBodyGeoLongitude(name, utcDate);
      const lon2 = minorBodyGeoLongitude(name, new Date(utcDate.getTime() + 86400000));
      let speed = lon2 - lon1;
      if (speed > 180) speed -= 360;
      if (speed < -180) speed += 360;
      positions[name] = { lon: lon1, retrograde: speed < 0, speed, minor: true, glyph, fullName };
    } else {
      const retro = seed() < 0.3;
      positions[name] = { lon: seed() * 360, retrograde: retro, speed: (SPEED_TABLE[name] || 0.01) * (retro ? -1 : 1), minor: true, glyph, fullName };
    }
  });

  let ascLon = 0, mcLon = 90;
  if (realEphemeris && !timeUnknown && birthData.lat != null && birthData.lng != null) {
    const angles = computeAngles(utcDate, birthData.lat, birthData.lng);
    ascLon = angles.asc; mcLon = angles.mc;
  } else if (!timeUnknown) {
    const [hh, mm] = birthData.time.split(":").map(Number);
    ascLon = (((hh + mm / 60) / 24) * 360 + seed() * 40) % 360;
    mcLon = (ascLon + 270) % 360; // aproximación de respaldo — consistente, no exacta
  } else {
    ascLon = seed() * 360;
    mcLon = (ascLon + 270) % 360;
  }
  const houseCusps = equalHouseCusps(ascLon);

  Object.keys(positions).forEach(name => {
    const lon = positions[name].lon;
    positions[name].sign = SIGN_NAMES_ES[signIndex(lon)];
    positions[name].house = timeUnknown ? "—" : houseFor(lon, ascLon);
    if (!positions[name].glyph) positions[name].glyph = PLANET_GLYPH[name];
  });

  const aspects = calculateAllAspects(positions);

  return {
    id: chartId, clientId: birthData.id, type: "natal", createdAt: "hoy", weeksAgo: 0,
    positions, houseCusps, aspects, ascLon, mcLon, housesReliable: !timeUnknown, interpGenerated: false,
    engine: realEphemeris ? "astronomy-engine (VSOP87/ELP2000) + elementos JPL SBDB para cuerpos menores" : "respaldo sin conexión"
  };
}
