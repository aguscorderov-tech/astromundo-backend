// /astrology-engine/ephemeris.js
// Envoltorio sobre la librería astronomy-engine (VSOP87/ELP2000, precisión
// menor a 1' de arco). Es el único archivo que le habla directo a `Astronomy`
// (el global que carga el <script> del CDN) — todo lo demás pasa por acá.

import { REAL_BODY_MAP } from "./planets.js";

export function hasRealEphemeris() {
  return typeof Astronomy !== "undefined";
}

// Longitud eclíptica geocéntrica "de fecha" (tropical) — misma referencia
// para Sol, Luna y planetas, así los aspectos entre ellos son consistentes.
export function eclipticLongitude(bodyKey, utcDate) {
  if (bodyKey === "sun") return Astronomy.SunPosition(utcDate).elon;
  if (bodyKey === "moon") return Astronomy.EclipticGeoMoon(utcDate).lon;
  const vec = Astronomy.GeoVector(REAL_BODY_MAP[bodyKey], utcDate, true);
  return Astronomy.Ecliptic(vec).elon;
}

// Velocidad real (°/día, con signo — negativo si retrógrado) por diferencia
// finita de un día. Se usa para marcar retrogradación y para "aplicativo/separativo".
export function realDailySpeed(bodyKey, utcDate) {
  const lon1 = eclipticLongitude(bodyKey, utcDate);
  const lon2 = eclipticLongitude(bodyKey, new Date(utcDate.getTime() + 86400000));
  let diff = lon2 - lon1;
  if (diff > 180) diff -= 360;
  if (diff < -180) diff += 360;
  return diff;
}

// Aproximación de respaldo si astronomy-engine no cargó (sin internet la
// primera vez). Solo el Sol se calcula con precisión real (día del año);
// el resto queda como aproximación — se documenta explícitamente en el
// campo `engine` de la carta resultante (ver natalChartService.js).
export function fallbackSunLongitude(dateStr) {
  if (!dateStr) return 141.87;
  const d = new Date(dateStr + "T12:00:00Z");
  const dayOfYear = Math.floor((d - new Date(Date.UTC(d.getUTCFullYear(), 0, 1))) / 86400000) + 1;
  return ((dayOfYear - 79) * (360 / 365.25) + 360) % 360; // 0° Aries ≈ 20 de marzo
}
