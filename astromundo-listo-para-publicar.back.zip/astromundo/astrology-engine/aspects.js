// /astrology-engine/aspects.js
// Todo lo referido a aspectos entre cuerpos. Funciones puras: reciben las
// posiciones que necesitan como parámetro, nunca leen estado global de la app
// (a diferencia de la versión original en el monolito, que llamaba a
// currentChart() directamente — ese acoplamiento es justo lo que se elimina
// al modularizar; el resultado numérico no cambia).

import { PLANET_KEYWORD, SPEED_TABLE } from "./planets.js";

export const ASPECT_COLOR = { conjunction:"#3C7A4A", sextile:"#3D6A8C", square:"#A8432A", trine:"#3D6A8C", opposition:"#A8432A", quincunx:"#8A6D1F" };
export const ASPECT_WIDTH = { conjunction:1.3, sextile:1, square:1.5, trine:1.5, opposition:1.8, quincunx:1 };
export const ASPECT_DASH  = { conjunction:"none", sextile:"3,2", square:"none", trine:"none", opposition:"none", quincunx:"1,2" };
export const ASPECT_GLYPH = { conjunction:"☌", sextile:"⚹", square:"□", trine:"△", opposition:"☍", quincunx:"⚻" };
export const ASPECT_LABEL = { conjunction:"Conjunción", sextile:"Sextil", square:"Cuadratura", trine:"Trígono", opposition:"Oposición", quincunx:"Quincuncio" };
export const ASPECT_ANGLE = { conjunction:0, sextile:60, square:90, trine:120, opposition:180, quincunx:150 };
export const ASPECT_VERB  = { conjunction:"se funde con", sextile:"favorece a", square:"tensiona a", trine:"fluye con", opposition:"polariza con", quincunx:"pide ajustar con" };
export const ORB_TABLE = { conjunction:[0,8], sextile:[60,4], square:[90,6], trine:[120,6], opposition:[180,8], quincunx:[150,3] };

export function calcAngleDiff(a, b) {
  const d = Math.abs(a - b) % 360;
  return Math.min(d, 360 - d);
}

// Encuentra qué tipo de aspecto forman dos longitudes, si hay alguno dentro del orbe.
// tight=true aplica el orbe reducido (3°) que se usa para cuerpos menores.
export function findAspect(lonA, lonB, tight) {
  const diff = calcAngleDiff(lonA, lonB);
  for (const [type, [angle, orb]] of Object.entries(ORB_TABLE)) {
    const eff = tight ? Math.min(orb, 3) : orb;
    if (Math.abs(diff - angle) <= eff) return type;
  }
  return null;
}

// Velocidad efectiva de un cuerpo dentro de una carta ya calculada (positions viene de generateChart()).
export function effectiveSpeed(positions, name) {
  return positions[name].speed != null ? positions[name].speed : (SPEED_TABLE[name] || 0.01);
}

// Aplicativo = el aspecto se está formando (el orbe se va cerrando); Separativo = se está alejando.
export function isApplying(positions, a, b, type) {
  const angle = ASPECT_ANGLE[type];
  const diffRaw = (((positions[a].lon - positions[b].lon) % 360) + 540) % 360 - 180;
  const candidates = (angle === 0 || angle === 180) ? [angle] : [angle, -angle];
  let target = candidates[0], minAbs = Infinity;
  candidates.forEach(c => { const d = Math.abs(diffRaw - c); if (d < minAbs) { minAbs = d; target = c; } });
  const delta = diffRaw - target;
  const rate = effectiveSpeed(positions, a) - effectiveSpeed(positions, b);
  return (delta * rate) < 0;
}

// Días estimados para que el aspecto sea exacto (o desde que lo fue, si es separativo). null si no es un dato útil.
export function daysToExact(positions, asp) {
  const rate = Math.abs(effectiveSpeed(positions, asp.a) - effectiveSpeed(positions, asp.b));
  if (rate < 0.005) return null;
  return Math.round(asp.orb / rate);
}

// Glosa automática de una línea: "identidad tensiona a emoción", etc.
// bodyLabelFn(name) debe devolver el nombre para mostrar de un cuerpo (lo resuelve natalChartService).
export function aspectGloss(asp, bodyLabelFn) {
  const kwA = PLANET_KEYWORD[asp.a] || bodyLabelFn(asp.a).toLowerCase();
  const kwB = PLANET_KEYWORD[asp.b] || bodyLabelFn(asp.b).toLowerCase();
  return `${kwA[0].toUpperCase() + kwA.slice(1)} ${ASPECT_VERB[asp.type]} ${kwB}`;
}

// Todos los aspectos entre los cuerpos de una carta — es lo que usa generateChart()
// para poblar chart.aspects, y también lo que arma la matriz del aspectario.
export function calculateAllAspects(positions) {
  const aspects = [];
  const names = Object.keys(positions);
  let aid = 1;
  for (let i = 0; i < names.length; i++) {
    for (let j = i + 1; j < names.length; j++) {
      const a = positions[names[i]].lon, b = positions[names[j]].lon;
      const diff = Math.min(Math.abs(a - b), 360 - Math.abs(a - b));
      const isMinorPair = positions[names[i]].minor || positions[names[j]].minor;
      for (const [type, [angle, orb]] of Object.entries(ORB_TABLE)) {
        const effOrb = isMinorPair ? Math.min(orb, 3) : orb;
        const delta = Math.abs(diff - angle);
        if (delta <= effOrb) { aspects.push({ id: "a" + (aid++), a: names[i], b: names[j], type, orb: delta, active: true }); break; }
      }
    }
  }
  return aspects;
}
