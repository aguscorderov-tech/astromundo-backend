// /components/ChartGallery.js
import { getCharts, fetchCharts } from "../services/natalChartService.js";
import { getClients, fetchClients } from "../services/clientService.js";
import { PLANET_COLOR, ELEMENT_COLOR, ZODIAC_SIGNS, ZODIAC_ELEMENTS, SIGN_NAMES_ES, signIndex } from "../astrology-engine/index.js";
import { openChart } from "./NatalChart.js";

export function renderMiniWheel(svgEl_, chart) {
  const CX = 85, CY = 85, R_OUT = 80, R_IN = 60, R_ASC_OUT = 86, R_PLANET = 46;
  const toXY = (lon, r) => { const rad = ((lon - chart.ascLon) + 180) * Math.PI / 180; return { x: CX + r * Math.cos(rad), y: CY - r * Math.sin(rad) }; };
  svgEl_.setAttribute("viewBox", "0 0 170 170");
  let html = "";
  for (let i = 0; i < 12; i++) {
    const p1 = toXY(i * 30, R_OUT), p2 = toXY(i * 30 + 30, R_OUT), p3 = toXY(i * 30 + 30, R_IN), p4 = toXY(i * 30, R_IN);
    html += `<path d="M ${p1.x} ${p1.y} A ${R_OUT} ${R_OUT} 0 0 1 ${p2.x} ${p2.y} L ${p3.x} ${p3.y} A ${R_IN} ${R_IN} 0 0 0 ${p4.x} ${p4.y} Z" fill="${ELEMENT_COLOR[ZODIAC_ELEMENTS[i]]}" opacity="0.14"/>`;
  }
  html += `<circle cx="${CX}" cy="${CY}" r="${R_OUT}" fill="none" stroke="#C9CBD4" stroke-width="1.2"/><circle cx="${CX}" cy="${CY}" r="${R_IN}" fill="none" stroke="#DCDEE5" stroke-width="1"/>`;
  for (let i = 0; i < 12; i++) {
    const p1 = toXY(i * 30, R_IN), p2 = toXY(i * 30, R_OUT);
    html += `<line x1="${p1.x}" y1="${p1.y}" x2="${p2.x}" y2="${p2.y}" stroke="#B0B3BE" stroke-width="0.8"/>`;
    const mid = toXY(i * 30 + 15, (R_OUT + R_IN) / 2);
    html += `<text x="${mid.x}" y="${mid.y+4}" text-anchor="middle" font-size="10" fill="${ELEMENT_COLOR[ZODIAC_ELEMENTS[i]]}" font-weight="600">${ZODIAC_SIGNS[i]}</text>`;
  }
  const ascP1 = toXY(chart.ascLon, R_IN - 12), ascP2 = toXY(chart.ascLon, R_ASC_OUT);
  html += `<line x1="${ascP1.x}" y1="${ascP1.y}" x2="${ascP2.x}" y2="${ascP2.y}" stroke="#B8863B" stroke-width="2"/>`;
  Object.entries(chart.positions).forEach(([name, d]) => {
    if (d.minor) return;
    const pos = toXY(d.lon, R_PLANET);
    const color = PLANET_COLOR[name] || "#1B2A4A";
    html += `<circle cx="${pos.x}" cy="${pos.y}" r="${(name === 'sun' || name === 'moon') ? 6 : 4.4}" fill="#FFFFFF" stroke="${color}" stroke-width="1.8"/><circle cx="${pos.x}" cy="${pos.y}" r="1.8" fill="${color}"/>`;
  });
  svgEl_.innerHTML = html;
}

export async function renderCartasGrid() {
  await Promise.all([fetchCharts(), fetchClients()]);
  const grid = document.getElementById("cartas-grid");
  const CLIENTS = getClients();
  grid.innerHTML = "";
  [...getCharts()].reverse().forEach(ch => {
    const client = CLIENTS.find(c => c.id === ch.clientId);
    const sunSign = ch.positions.sun.sign, moonSign = ch.positions.moon.sign;
    const ascSign = SIGN_NAMES_ES[signIndex(ch.ascLon)];
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `
      <div class="card-top"><span class="type-tag natal">Natal</span></div>
      <div class="card-body">
        <div class="mini-wheel-wrap"><svg width="170" height="170"></svg></div>
        <div class="card-info">
          <h3>Carta natal completa</h3>
          <div class="who">${client ? client.name : "—"}</div>
          <div class="placements"><span style="color:${PLANET_COLOR.sun}">☉</span> ${sunSign} · <span style="color:${PLANET_COLOR.moon}">☽</span> ${moonSign}<br>ASC ${ascSign}</div>
        </div>
      </div>
      <div class="card-foot"><span>${ch.createdAt}</span></div>
    `;
    card.addEventListener("click", () => openChart(ch.id));
    grid.appendChild(card);
    renderMiniWheel(card.querySelector("svg"), ch);
  });
}
