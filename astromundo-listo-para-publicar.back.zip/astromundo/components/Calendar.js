// /components/Calendar.js
import { getClients, fetchClients } from "../services/clientService.js";
import { getServices, fetchServices } from "../services/paymentService.js";
import {
  getAppointments, fetchAppointments, createAppointment, updateAppointment,
  getAgendaWeekOffset, shiftAgendaWeek, countAppointmentsByDay
} from "../services/calendarService.js";
import { WEEKDAY_LABELS, AGENDA_REFERENCE_MONDAY_UTC } from "../config/constants.js";
import { SETTINGS } from "../config/settings.js";
import { svgNode } from "./Charts.js";

const { startHour: AGENDA_START_HOUR, endHour: AGENDA_END_HOUR } = SETTINGS.agenda;
let editingApptId = null;

function renderAgendaHeader() {
  const head = document.getElementById("cal-head");
  const [y, m, d] = AGENDA_REFERENCE_MONDAY_UTC;
  const base = new Date(Date.UTC(y, m, d));
  base.setUTCDate(base.getUTCDate() + getAgendaWeekOffset() * 7);
  let html = "<div></div>";
  for (let i = 0; i < 7; i++) {
    const dt = new Date(base); dt.setUTCDate(base.getUTCDate() + i);
    const isToday = getAgendaWeekOffset() === 0 && i === 2; // miércoles = "hoy" en esta demo
    html += `<div>${WEEKDAY_LABELS[i]}<span class="daynum ${isToday ? "today" : ""}">${dt.getUTCDate()}</span></div>`;
  }
  head.innerHTML = html;
  const endDate = new Date(base); endDate.setUTCDate(base.getUTCDate() + 6);
  const monthNames = ["ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic"];
  document.getElementById("agenda-week-label").textContent =
    `${base.getUTCDate()} – ${endDate.getUTCDate()} de ${monthNames[endDate.getUTCMonth()]}`;
}

function renderAgendaGrid() {
  const CLIENTS = getClients(), SERVICES = getServices(), APPOINTMENTS = getAppointments();
  const body = document.getElementById("cal-body");
  body.innerHTML = "";
  const hourCol = document.createElement("div");
  hourCol.className = "hour-col"; hourCol.id = "hour-col";
  for (let h = AGENDA_START_HOUR; h <= AGENDA_END_HOUR; h++) {
    const d = document.createElement("div"); d.textContent = h + ":00"; hourCol.appendChild(d);
  }
  body.appendChild(hourCol);

  const cols = [];
  for (let i = 0; i < 7; i++) {
    const col = document.createElement("div");
    col.className = "day-col"; col.dataset.day = i;
    for (let h = AGENDA_START_HOUR; h <= AGENDA_END_HOUR; h++) {
      const slot = document.createElement("div");
      slot.className = "slot";
      slot.addEventListener("click", () => openAppointmentForm(null, i, h + ":00"));
      col.appendChild(slot);
    }
    body.appendChild(col);
    cols.push(col);
  }

  const SLOT_H = 52;
  if (getAgendaWeekOffset() === 0) {
    APPOINTMENTS.forEach(ap => {
      const [hh, mm] = ap.time.split(":").map(Number);
      const svc = SERVICES.find(s => s.id === ap.serviceId);
      const durationMin = (svc && svc.duration) || 30;
      const startHour = hh + mm / 60;
      if (startHour < AGENDA_START_HOUR || startHour > AGENDA_END_HOUR) return;
      const top = (startHour - AGENDA_START_HOUR) * SLOT_H;
      const height = Math.max((durationMin / 60) * SLOT_H, 28);
      const client = CLIENTS.find(c => c.id === ap.clientId);
      const block = document.createElement("div");
      block.className = "appt-block " + ap.status;
      block.style.top = top + "px";
      block.style.height = height + "px";
      block.innerHTML = `<div class="t">${ap.time}</div><div class="n">${client ? client.name : "—"}</div>`;
      block.addEventListener("click", (e) => { e.stopPropagation(); openAppointmentForm(ap); });
      cols[ap.day].appendChild(block);
    });
  }
}

function renderOccupancyChart() {
  const counts = getAgendaWeekOffset() === 0 ? countAppointmentsByDay() : [0,0,0,0,0,0,0];
  const totalSlots = AGENDA_END_HOUR - AGENDA_START_HOUR + 1;
  const data = WEEKDAY_LABELS.map((lbl, i) => ({
    label: lbl, value: Math.round((counts[i] / totalSlots) * 100), color: counts[i] > 0 ? "#0F5C5C" : "#DCDEE5"
  }));
  const svg = document.getElementById("chart-ocupacion");
  svg.innerHTML = "";
  const H = 70, barW = 70, gap = 100, padBottom = 18;
  data.forEach((d, i) => {
    const h = ((H - padBottom - 14) * Math.max(d.value, 2)) / 100;
    const x = i * gap + (gap - barW) / 2;
    const y = H - padBottom - h;
    const rect = svgNode("rect", { x, y, width: barW, height: h, rx: 4, fill: d.color });
    const title = svgNode("title", {}); title.textContent = `${d.label}: ${d.value}% ocupado`;
    rect.appendChild(title);
    svg.appendChild(rect);
    const lbl = svgNode("text", { x: x + barW / 2, y: H - 4, "text-anchor": "middle", "font-size": 10, fill: "#6B7280" });
    lbl.textContent = d.label; svg.appendChild(lbl);
  });
}

export async function renderAgenda() {
  await Promise.all([fetchClients(), fetchServices(), fetchAppointments()]);
  renderAgendaHeader();
  renderAgendaGrid();
  renderOccupancyChart();
}

function openAppointmentForm(appt, prefillDay, prefillTime) {
  const CLIENTS = getClients(), SERVICES = getServices();
  editingApptId = appt ? appt.id : null;
  document.getElementById("agenda-form-title").textContent = appt ? "Editar turno" : "Nuevo turno";
  const clientSel = document.getElementById("ag-client");
  clientSel.innerHTML = CLIENTS.map(c => `<option value="${c.id}">${c.name}</option>`).join("");
  const svcSel = document.getElementById("ag-service");
  svcSel.innerHTML = SERVICES.map(s => `<option value="${s.id}">${s.name} — $${s.price.toLocaleString("es-AR")}</option>`).join("");
  const daySel = document.getElementById("ag-day");
  daySel.innerHTML = WEEKDAY_LABELS.map((l, i) => `<option value="${i}">${l}</option>`).join("");

  if (appt) {
    clientSel.value = appt.clientId; svcSel.value = appt.serviceId; daySel.value = appt.day;
    document.getElementById("ag-time").value = appt.time;
    document.getElementById("ag-status").value = appt.status;
  } else {
    daySel.value = prefillDay != null ? prefillDay : 0;
    document.getElementById("ag-time").value = prefillTime || "10:00";
    document.getElementById("ag-status").value = "confirmed";
  }
  document.getElementById("agenda-form-panel").style.display = "block";
  document.getElementById("agenda-form-panel").scrollIntoView({ behavior: "smooth", block: "nearest" });
}

export function initCalendarComponent() {
  document.getElementById("agenda-prev").addEventListener("click", () => { shiftAgendaWeek(-1); renderAgenda(); });
  document.getElementById("agenda-next").addEventListener("click", () => { shiftAgendaWeek(1); renderAgenda(); });
  document.getElementById("agenda-new-btn").addEventListener("click", () => openAppointmentForm(null, 0, "10:00"));
  document.getElementById("ag-cancel-btn").addEventListener("click", () => { document.getElementById("agenda-form-panel").style.display = "none"; });
  document.getElementById("ag-save-btn").addEventListener("click", async () => {
    const clientId = document.getElementById("ag-client").value;
    const serviceId = document.getElementById("ag-service").value;
    const day = parseInt(document.getElementById("ag-day").value, 10);
    const time = document.getElementById("ag-time").value.trim() || "10:00";
    const status = document.getElementById("ag-status").value;

    try {
      if (editingApptId) {
        await updateAppointment(editingApptId, { clientId, serviceId, day, time, status });
      } else {
        await createAppointment({ clientId, serviceId, day, time, status });
      }
      document.getElementById("agenda-form-panel").style.display = "none";
      renderAgenda();
    } catch (err) {
      alert("No se pudo guardar el turno: " + err.message);
    }
  });
}
