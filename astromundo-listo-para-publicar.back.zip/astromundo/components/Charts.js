// /components/Charts.js
// Helpers de gráficos SVG genéricos — no saben nada de cartas, turnos ni
// clientes: reciben datos ya formados ({label, value, color}) y dibujan.
// Los usan Dashboard.js y Calendar.js (gráfico de ocupación).

export function svgNode(tag, attrs) {
  const el = document.createElementNS("http://www.w3.org/2000/svg", tag);
  for (const k in attrs) el.setAttribute(k, attrs[k]);
  return el;
}

export function renderBarChart(svgId, data, opts) {
  const svg = document.getElementById(svgId);
  if (!svg) return;
  svg.innerHTML = "";
  const vb = (svg.viewBox && svg.viewBox.baseVal) || {};
  const W = vb.width || 560, H = vb.height || 170;
  const padBottom = 24, padTop = 10;
  const max = Math.max(1, ...data.map(d => d.value));
  const barW = (W / data.length) * 0.55;
  const gap = (W / data.length);
  data.forEach((d, i) => {
    const h = ((H - padBottom - padTop) * d.value) / max;
    const x = i * gap + (gap - barW) / 2;
    const y = H - padBottom - h;
    const rect = svgNode("rect", { x, y, width: barW, height: Math.max(h, 2), rx: 4, fill: d.color || "#B8863B" });
    const title = svgNode("title", {}); title.textContent = `${d.label}: ${d.value}`;
    rect.appendChild(title);
    if (opts && opts.onClick) { rect.style.cursor = "pointer"; rect.addEventListener("click", () => opts.onClick(d, i)); }
    svg.appendChild(rect);
    const lbl = svgNode("text", { x: x + barW / 2, y: H - 7, "text-anchor": "middle", "font-size": 10, fill: "#6B7280", "font-family": "IBM Plex Sans, sans-serif" });
    lbl.textContent = d.label;
    svg.appendChild(lbl);
    if (d.value > 0) {
      const vLbl = svgNode("text", { x: x + barW / 2, y: y - 5, "text-anchor": "middle", "font-size": 10.5, fill: "#1B2A4A", "font-family": "IBM Plex Mono, monospace" });
      vLbl.textContent = d.value;
      svg.appendChild(vLbl);
    }
  });
}

export function renderDonutChart(svgId, data, legendId) {
  const svg = document.getElementById(svgId);
  if (!svg) return;
  svg.innerHTML = "";
  const cx = 70, cy = 70, r = 52, strokeW = 22;
  const total = data.reduce((s, d) => s + d.value, 0) || 1;
  const C = 2 * Math.PI * r;
  let offsetAcc = 0;
  svg.appendChild(svgNode("circle", { cx, cy, r, fill: "none", stroke: "#EDEEF2", "stroke-width": strokeW }));
  data.forEach(d => {
    const frac = d.value / total;
    const dash = frac * C;
    const circle = svgNode("circle", {
      cx, cy, r, fill: "none", stroke: d.color, "stroke-width": strokeW,
      "stroke-dasharray": `${dash} ${C - dash}`, "stroke-dashoffset": -offsetAcc,
      transform: `rotate(-90 ${cx} ${cy})`, "stroke-linecap": "butt"
    });
    const title = svgNode("title", {}); title.textContent = `${d.label}: ${d.value} (${Math.round(frac * 100)}%)`;
    circle.appendChild(title);
    svg.appendChild(circle);
    offsetAcc += dash;
  });
  const centerLbl = svgNode("text", { x: cx, y: cy + 5, "text-anchor": "middle", "font-size": 15, fill: "#1B2A4A", "font-family": "IBM Plex Mono, monospace", "font-weight": "600" });
  centerLbl.textContent = total;
  svg.appendChild(centerLbl);
  const subLbl = svgNode("text", { x: cx, y: cy + 18, "text-anchor": "middle", "font-size": 8.5, fill: "#6B7280" });
  subLbl.textContent = "cartas";
  svg.appendChild(subLbl);

  if (legendId) {
    const legend = document.getElementById(legendId);
    legend.innerHTML = data.map(d => `
      <div style="display:flex;align-items:center;gap:7px;margin-bottom:7px;">
        <span style="width:10px;height:10px;border-radius:3px;background:${d.color};flex-shrink:0;"></span>
        <span style="color:var(--text-muted);">${d.label}</span>
        <span style="margin-left:auto;font-family:'IBM Plex Mono',monospace;color:var(--navy-deep);">${d.value}</span>
      </div>`).join("");
  }
}
