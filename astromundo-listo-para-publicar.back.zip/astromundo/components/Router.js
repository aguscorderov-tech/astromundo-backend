// /components/Router.js
// Cambia qué <div class="view"> está visible y avisa a la vista entrante que
// se redibuje. No importa los componentes de cada vista directamente (eso
// crearía un ciclo: Dashboard necesita navigate() para sus tarjetas clicables,
// y Router necesitaría renderDashboard() para mostrar el panel) — en cambio,
// cada vista se registra a sí misma con registerView() desde app.js, y la
// navegación entre vistas usa delegación de eventos sobre [data-goto], así
// ningún componente necesita importar Router para navegar.

const views = {};

export function registerView(name, renderFn) {
  views[name] = renderFn;
}

export function navigate(name) {
  document.querySelectorAll(".view").forEach(v => v.classList.remove("active"));
  document.getElementById("view-" + name).classList.add("active");
  document.querySelectorAll(".nav-link").forEach(a => a.classList.toggle("active", a.dataset.view === name));
  window.scrollTo(0, 0);
  if (views[name]) {
    // Las vistas ahora traen datos del backend (async) — si falla la
    // petición (sesión vencida, backend caído), no debe romper la app en
    // silencio: se avisa por consola como mínimo.
    Promise.resolve(views[name]()).catch(err => console.error(`Error al cargar la vista "${name}":`, err));
  }
}

export function initRouter() {
  // Delegación de eventos: funciona también para elementos [data-goto] creados
  // dinámicamente (tarjetas del dashboard, filas de tablas), no solo los que
  // existen en el HTML al cargar la página.
  document.addEventListener("click", (e) => {
    const el = e.target.closest("[data-goto]");
    if (el) navigate(el.dataset.goto);
  });
  document.querySelectorAll(".nav-link").forEach(el => {
    el.addEventListener("click", () => navigate(el.dataset.view));
  });
}
