// /components/Auth.js
import { login, register, logout, restoreSession, getCurrentUser, isAuthenticated } from "../services/userService.js";
import { ApiError } from "../services/apiClient.js";

let onAuthenticated = null; // callback que dispara app.js cuando hay sesión válida

function showError(message) {
  const el = document.getElementById("auth-error");
  el.textContent = message;
  el.style.display = "block";
}
function clearError() {
  document.getElementById("auth-error").style.display = "none";
}

export function updateSidebarUser() {
  const user = getCurrentUser();
  if (!user) return;
  document.getElementById("user-name").textContent = user.name;
  document.getElementById("user-plan").textContent = "Plan " + (user.plan[0].toUpperCase() + user.plan.slice(1));
}

export function initAuthComponent(callback) {
  onAuthenticated = callback;

  document.getElementById("auth-tab-login").addEventListener("click", () => {
    document.getElementById("auth-tab-login").classList.add("active");
    document.getElementById("auth-tab-register").classList.remove("active");
    document.getElementById("auth-form-login").style.display = "block";
    document.getElementById("auth-form-register").style.display = "none";
    clearError();
  });
  document.getElementById("auth-tab-register").addEventListener("click", () => {
    document.getElementById("auth-tab-register").classList.add("active");
    document.getElementById("auth-tab-login").classList.remove("active");
    document.getElementById("auth-form-register").style.display = "block";
    document.getElementById("auth-form-login").style.display = "none";
    clearError();
  });

  document.getElementById("login-btn").addEventListener("click", async () => {
    clearError();
    const email = document.getElementById("login-email").value.trim();
    const password = document.getElementById("login-password").value;
    if (!email || !password) { showError("Completá email y contraseña."); return; }
    try {
      await login({ email, password });
      updateSidebarUser();
      onAuthenticated();
    } catch (e) {
      showError(e instanceof ApiError ? e.message : "No se pudo conectar con el backend. ¿Está corriendo?");
    }
  });

  document.getElementById("register-btn").addEventListener("click", async () => {
    clearError();
    const name = document.getElementById("register-name").value.trim();
    const email = document.getElementById("register-email").value.trim();
    const password = document.getElementById("register-password").value;
    if (!name || !email || !password) { showError("Completá nombre, email y contraseña."); return; }
    try {
      await register({ name, email, password });
      updateSidebarUser();
      onAuthenticated();
    } catch (e) {
      showError(e instanceof ApiError ? e.message : "No se pudo conectar con el backend. ¿Está corriendo?");
    }
  });

  document.getElementById("logout-link").addEventListener("click", () => {
    logout();
    document.getElementById("app-sidebar").style.display = "none";
    document.querySelectorAll(".view").forEach(v => v.classList.remove("active"));
    document.getElementById("view-auth").classList.add("active");
  });
}

// Se llama al arrancar la app: si hay un token guardado, intenta restaurar
// la sesión antes de mostrar el login — para que no haya que reingresar
// cada vez que se recarga la página.
export async function tryRestoreSession() {
  if (!isAuthenticated()) return false;
  const user = await restoreSession();
  if (user) { updateSidebarUser(); return true; }
  return false;
}
