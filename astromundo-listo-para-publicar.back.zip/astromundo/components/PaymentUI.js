// /components/PaymentUI.js
import { getClients, fetchClients } from "../services/clientService.js";
import { fetchServices, fetchPaymentsSummary } from "../services/paymentService.js";

export async function renderPagos() {
  await Promise.all([fetchClients(), fetchServices()]);
  const clientsById = Object.fromEntries(getClients().map(c => [c.id, c.name]));
  const { rows, totalBruto, totalComision, aprobados, neto } = await fetchPaymentsSummary(clientsById);

  const tbody = document.getElementById("pagos-table");
  tbody.innerHTML = rows.length ? rows.map(r => `
    <tr>
      <td class="mono">${r.day} ago</td>
      <td>${r.name}</td>
      <td>${r.concept}</td>
      <td class="mono">$${r.monto.toLocaleString("es-AR")}</td>
      <td class="mono" style="color:var(--text-muted);">$${r.comision.toLocaleString("es-AR")}</td>
      <td><span class="tx-status ${r.approved ? "approved" : "pending"}">${r.approved ? "Aprobado" : "Pendiente"}</span></td>
    </tr>
  `).join("") : `<tr><td colspan="6" style="color:var(--text-muted);font-size:13px;">Todavía no hay movimientos registrados.</td></tr>`;

  document.getElementById("pagos-resumen").innerHTML = `
    <div class="appt"><div class="time mono">$</div><div><div class="who">Ingreso bruto del mes</div><div class="what">${aprobados} pagos aprobados</div></div><span class="tag mono">$${totalBruto.toLocaleString("es-AR")}</span></div>
    <div class="appt"><div class="time mono">%</div><div><div class="who">Comisión de la plataforma</div><div class="what">Según tu plan</div></div><span class="tag mono" style="background:rgba(156,122,60,0.14);color:var(--brass);">$${totalComision.toLocaleString("es-AR")}</span></div>
    <div class="appt"><div class="time mono">=</div><div><div class="who">Neto a tu cuenta</div><div class="what">Después de comisión</div></div><span class="tag mono">$${neto.toLocaleString("es-AR")}</span></div>
  `;
}
