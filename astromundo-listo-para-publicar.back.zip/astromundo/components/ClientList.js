// /components/ClientList.js
import { getClients, fetchClients } from "../services/clientService.js";
import { getChartsByClient, fetchCharts } from "../services/natalChartService.js";
import { openFicha } from "./ClientProfile.js";
import { openChart } from "./NatalChart.js";

// Dibuja sobre lo que ya está en caché — la usa tanto la carga inicial de la
// vista como el buscador (que filtra en el cliente, sin volver a pedirle
// nada al backend en cada tecla).
export function renderClientsTable(filter) {
  const tbody = document.getElementById("clients-table");
  tbody.innerHTML = "";
  const q = (filter || "").toLowerCase();
  getClients().filter(c => c.name.toLowerCase().includes(q)).forEach(c => {
    const clientCharts = getChartsByClient(c.id);
    const initials = c.name.split(" ").map(w => w[0]).slice(0, 2).join("").toUpperCase();
    const tr = document.createElement("tr");
    tr.className = "row-link";
    tr.innerHTML = `
      <td><div class="client-cell"><div class="initials">${initials}</div><div><div style="font-weight:500;">${c.name}</div><div style="font-size:11.5px;color:var(--text-muted);">${c.email || ""}</div></div></div></td>
      <td>${clientCharts.length ? "Carta natal" : "—"}</td>
      <td>${clientCharts.length}</td>
      <td class="row-actions"><a data-chart="${clientCharts[0] ? clientCharts[0].id : ''}">${clientCharts.length ? "Ver carta" : ""}</a></td>
    `;
    tr.addEventListener("click", (e) => {
      if (e.target.closest("a")) { e.stopPropagation(); if (clientCharts[0]) openChart(clientCharts[0].id); return; }
      openFicha(c.id);
    });
    tbody.appendChild(tr);
  });
}

export async function loadClientsView() {
  await Promise.all([fetchClients(), fetchCharts()]);
  renderClientsTable();
}

export function initClientListComponent() {
  document.getElementById("client-search").addEventListener("input", (e) => renderClientsTable(e.target.value));
}
