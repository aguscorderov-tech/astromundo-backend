// /components/Dashboard.js
import { getClients, fetchClients } from "../services/clientService.js";
import { getCharts, fetchCharts } from "../services/natalChartService.js";
import { getAppointments, fetchAppointments } from "../services/calendarService.js";
import { getServices, fetchServices } from "../services/paymentService.js";
import { dominantElement, ELEMENT_COLOR } from "../astrology-engine/index.js";
import { WEEKDAY_LABELS } from "../config/constants.js";
import { renderBarChart, renderDonutChart } from "./Charts.js";
import { navigate } from "./Router.js";
import { openFicha } from "./ClientProfile.js";
import { openChart } from "./NatalChart.js";

export async function renderDashboard() {
  await Promise.all([fetchClients(), fetchCharts(), fetchAppointments(), fetchServices()]);
  const CLIENTS = getClients(), CHARTS = getCharts(), APPOINTMENTS = getAppointments(), SERVICES = getServices();

  document.getElementById("stat-charts").textContent = CHARTS.length;
  document.getElementById("stat-clients").textContent = CLIENTS.length;
  document.getElementById("stat-appts").textContent = APPOINTMENTS.length;

  const approxIncome = APPOINTMENTS.reduce((sum, ap) => {
    const svc = SERVICES.find(s => s.id === ap.serviceId);
    return sum + (svc && ap.status !== "pending" ? svc.price : 0);
  }, 0);
  document.getElementById("stat-income").textContent = "$" + approxIncome.toLocaleString("es-AR");

  // Gráfico: cartas generadas en las últimas 6 semanas (semana actual a la derecha)
  const weekBuckets = [5, 4, 3, 2, 1, 0].map(w => ({
    label: w === 0 ? "Esta sem." : `-${w}sem`,
    value: CHARTS.filter(ch => ch.weeksAgo === w).length,
    color: w === 0 ? "#B8863B" : "#1B2A4A"
  }));
  renderBarChart("chart-cartas-semana", weekBuckets, { onClick: () => navigate("cartas") });

  // Donut: elemento dominante entre todas las cartas generadas
  const elCounts = { fire: 0, earth: 0, air: 0, water: 0 };
  CHARTS.forEach(ch => elCounts[dominantElement(ch.positions)]++);
  renderDonutChart("chart-elementos", [
    { label: "Fuego", value: elCounts.fire, color: ELEMENT_COLOR.fire },
    { label: "Tierra", value: elCounts.earth, color: ELEMENT_COLOR.earth },
    { label: "Aire", value: elCounts.air, color: ELEMENT_COLOR.air },
    { label: "Agua", value: elCounts.water, color: ELEMENT_COLOR.water }
  ], "chart-elementos-legend");

  // Próximos turnos (reales, ordenados por día/hora)
  const apptsEl = document.getElementById("dashboard-appts");
  apptsEl.innerHTML = "";
  const sortedAppts = [...APPOINTMENTS].sort((a, b) => a.day - b.day || a.time.localeCompare(b.time)).slice(0, 4);
  if (!sortedAppts.length) apptsEl.innerHTML = `<div style="font-size:13px;color:var(--text-muted);">No hay turnos cargados.</div>`;
  sortedAppts.forEach(ap => {
    const client = CLIENTS.find(c => c.id === ap.clientId);
    const svc = SERVICES.find(s => s.id === ap.serviceId);
    const div = document.createElement("div");
    div.className = "appt";
    div.innerHTML = `<div class="time mono">${WEEKDAY_LABELS[ap.day]} ${ap.time}</div><div><div class="who">${client ? client.name : "—"}</div><div class="what">${svc ? svc.name : "—"}</div></div><span class="tag" style="${ap.status === 'pending' ? 'background:rgba(179,70,44,.1);color:var(--rust);' : (ap.status === 'async' ? 'background:rgba(184,134,59,.14);color:var(--brass);' : '')}">${ap.status === "confirmed" ? "Confirmado" : ap.status === "pending" ? "Pendiente" : "Async"}</span>`;
    div.addEventListener("click", () => client && openFicha(client.id));
    apptsEl.appendChild(div);
  });

  const chartsEl = document.getElementById("dashboard-charts");
  chartsEl.innerHTML = "";
  [...CHARTS].reverse().slice(0, 4).forEach(ch => {
    const client = CLIENTS.find(c => c.id === ch.clientId);
    const div = document.createElement("div");
    div.className = "appt";
    div.innerHTML = `<div class="time mono">☉</div><div><div class="who">${client ? client.name : "—"}</div><div class="what">Carta natal</div></div><span class="tag">Ver →</span>`;
    div.addEventListener("click", () => openChart(ch.id));
    chartsEl.appendChild(div);
  });
}
