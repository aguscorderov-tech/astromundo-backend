// /components/SearchBox.js
// Único punto de la UI que habla con /search-engine. Expone getSelectedPlace()
// para que NewChartForm.js lea el resultado al enviar — el resto de los
// componentes no necesitan saber cómo se buscó un lugar.

import { searchLocationsDebounced } from "../search-engine/locationSearch.js";
import { displayOffset } from "../search-engine/geocoding.js";

let ncPlaceInput, ncSuggestions, ncPlaceConfirmed, ncManualCoords;
let selectedPlace = { name: "Rosario, Santa Fe, Argentina", lat: -32.9468, lng: -60.6393, tz: "UTC-3", tzName: "America/Argentina/Buenos_Aires" };

export function getSelectedPlace() {
  return selectedPlace;
}

export function focusPlaceInput() {
  if (ncPlaceInput) ncPlaceInput.focus();
}

function showManualFallback(message) {
  ncSuggestions.innerHTML = `<div class="place-empty visible">${message} <button type="button" id="nc-manual-btn">Ingresar coordenadas manualmente</button></div>`;
  document.getElementById("nc-manual-btn").addEventListener("click", () => {
    ncSuggestions.classList.remove("visible");
    ncManualCoords.classList.add("visible");
  });
}

export function initSearchBox() {
  ncPlaceInput = document.getElementById("nc-place");
  ncSuggestions = document.getElementById("nc-place-suggestions");
  ncPlaceConfirmed = document.getElementById("nc-place-confirmed");
  ncManualCoords = document.getElementById("nc-manual-coords");

  ncPlaceInput.addEventListener("input", () => {
    const q = ncPlaceInput.value.trim();
    selectedPlace = null;
    ncPlaceConfirmed.classList.remove("visible");
    ncManualCoords.classList.remove("visible");
    if (q.length < 2) { ncSuggestions.classList.remove("visible"); return; }

    ncSuggestions.innerHTML = `<div class="place-empty visible">Buscando "${q}" en la base mundial (GeoNames)...</div>`;
    ncSuggestions.classList.add("visible");

    searchLocationsDebounced(q, {
      onResults: (results, forQuery) => {
        if (ncPlaceInput.value.trim() !== forQuery) return; // el usuario ya siguió tipeando
        if (!results.length) { showManualFallback(`Sin coincidencias para "${forQuery}".`); return; }
        ncSuggestions.innerHTML = results.map((p, i) =>
          `<div class="place-option" data-idx="${i}"><span>${p.name}</span><span class="tz">${p.tzName}</span></div>`
        ).join("");
        ncSuggestions._lastResults = results;
      },
      onError: () => showManualFallback("No se pudo consultar la base mundial (¿sin conexión?)."),
    });
  });

  ncSuggestions.addEventListener("click", (e) => {
    const opt = e.target.closest(".place-option");
    if (!opt || !ncSuggestions._lastResults) return;
    const p = ncSuggestions._lastResults[+opt.dataset.idx];
    ncPlaceInput.value = p.name;
    ncSuggestions.classList.remove("visible");
    ncManualCoords.classList.remove("visible");
    const tzDisplay = displayOffset(p.tzName);
    selectedPlace = { name: p.name, lat: p.lat, lng: p.lng, tz: tzDisplay, tzName: p.tzName };
    ncPlaceConfirmed.innerHTML = `<span>✓ ${p.name}</span><span class="coords">${p.lat.toFixed(4)}, ${p.lng.toFixed(4)} · ${tzDisplay}${p.elevation != null ? " · " + Math.round(p.elevation) + "m s.n.m." : ""}</span>`;
    ncPlaceConfirmed.classList.add("visible");
  });

  // Coordenadas manuales: sin nombre de lugar no hay zona IANA — se usa el offset
  // fijo que cargue el astrólogo (no resuelve horario de verano histórico solo).
  ["nc-manual-lat", "nc-manual-lng", "nc-manual-tz"].forEach(id => {
    document.getElementById(id).addEventListener("input", () => {
      const lat = parseFloat(document.getElementById("nc-manual-lat").value);
      const lng = parseFloat(document.getElementById("nc-manual-lng").value);
      const tz = document.getElementById("nc-manual-tz").value.trim();
      selectedPlace = (!isNaN(lat) && !isNaN(lng) && tz)
        ? { name: ncPlaceInput.value.trim() || "Coordenadas manuales", lat, lng, tz, tzName: null }
        : null;
    });
  });

  document.addEventListener("click", (e) => { if (!e.target.closest(".place-wrap")) ncSuggestions.classList.remove("visible"); });
}
