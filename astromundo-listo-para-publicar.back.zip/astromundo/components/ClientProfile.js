// /components/ClientProfile.js
import { getCurrentClient, setCurrentClientId, formatDate, fetchClients } from "../services/clientService.js";
import { getChartsByClient, fetchCharts } from "../services/natalChartService.js";
import { navigate } from "./Router.js";
import { openChart } from "./NatalChart.js";

// openFicha se puede llamar desde varias pantallas (lista de clientes,
// turnos del dashboard) — por eso vuelve a traer datos frescos acá en vez
// de asumir que ya están en caché de una vista anterior.
export async function openFicha(clientId) {
  setCurrentClientId(clientId);
  await Promise.all([fetchClients(), fetchCharts()]);
  const c = getCurrentClient();
  if (!c) { alert("No se encontró el cliente."); return; }

  document.getElementById("ficha-name").textContent = c.name;
  document.getElementById("ficha-datos").innerHTML = `
    <div><b>Email:</b> ${c.email || "—"}</div>
    <div><b>Nacimiento:</b> ${formatDate(c.date)} · ${c.timeUnknown ? "hora desconocida" : (c.time + " (" + c.tz + ")")}</div>
    <div><b>Lugar:</b> ${c.place}</div>
  `;
  const chartsEl = document.getElementById("ficha-cartas");
  const clientCharts = getChartsByClient(c.id);
  chartsEl.innerHTML = clientCharts.length ? "" : `<div style="font-size:13px;color:var(--text-muted);">Todavía no tiene cartas generadas.</div>`;
  clientCharts.forEach(ch => {
    const div = document.createElement("div");
    div.className = "appt";
    div.innerHTML = `<div class="time mono">☉</div><div><div class="who">Carta natal</div><div class="what">${ch.createdAt}</div></div><span class="tag">Ver →</span>`;
    div.addEventListener("click", () => openChart(ch.id));
    chartsEl.appendChild(div);
  });
  document.getElementById("ficha-new-chart-btn").onclick = () => {
    navigate("nueva-carta");
    document.getElementById("nc-client-select").value = c.id;
  };
  navigate("ficha");
}
