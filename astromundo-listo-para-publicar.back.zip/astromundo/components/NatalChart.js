// /components/NatalChart.js
// El componente más grande de la app: dibuja la rueda y todos sus paneles.
// Cálculo puro (getDecan, isApplying, aspectGloss, etc.) viene de
// astrology-engine — acá solo se decide CÓMO se ve, nunca se recalcula nada.

import {
  ELEMENT_COLOR, ZODIAC_ELEMENTS, ZODIAC_SIGNS, DECAN_RULERS, RULER_NAME, SIGN_NAMES_ES, signIndex, getDecan,
  PLANET_COLOR, PLANET_KEYWORD, ANGLES,
  ASPECT_COLOR, ASPECT_WIDTH, ASPECT_DASH, ASPECT_GLYPH, ASPECT_LABEL, ORB_TABLE,
  isApplying, daysToExact, aspectGloss, calcAngleDiff, findAspect
} from "../astrology-engine/index.js";
import { getCurrentChart, setCurrentChartId, bodyLabel, saveInterpretation } from "../services/natalChartService.js";
import { getCurrentClient, setCurrentClientId, formatDate } from "../services/clientService.js";
import { generateInterpretation } from "../services/aiService.js";
import { navigate } from "./Router.js";

let showMinorBodies = true;
let hoveredAspectId = null;
const CX = 260, CY = 260;
const R_ZODIAC_OUT = 213, R_ZODIAC_IN = 188, R_TICK_OUT = 221;
const R_HOUSE = 185, R_PLANET = 152, R_ASPECT = 122, R_MINOR = 163, R_ANGLE_OUT = 226;

function degToDM(lon) { const s = lon % 30; const d = Math.floor(s); const m = Math.round((s - d) * 60); return `${d}°${m.toString().padStart(2, "0")}'`; }
function toXY(lonDeg, radius) {
  const chart = getCurrentChart();
  const rad = ((lonDeg - chart.ascLon) + 180) * Math.PI / 180;
  return { x: CX + radius * Math.cos(rad), y: CY - radius * Math.sin(rad) };
}
function svgEl(tag, attrs) { const el = document.createElementNS("http://www.w3.org/2000/svg", tag); for (const k in attrs) el.setAttribute(k, attrs[k]); return el; }
function wedgePath(s, e, rO, rI) { const p1 = toXY(s, rO), p2 = toXY(e, rO), p3 = toXY(e, rI), p4 = toXY(s, rI); return `M ${p1.x} ${p1.y} A ${rO} ${rO} 0 0 1 ${p2.x} ${p2.y} L ${p3.x} ${p3.y} A ${rI} ${rI} 0 0 0 ${p4.x} ${p4.y} Z`; }

const tooltip = () => document.getElementById("tooltip");
function showTooltip(e, text) {
  const rect = document.querySelector(".wheel-wrap").getBoundingClientRect();
  const t = tooltip();
  t.style.left = (e.clientX - rect.left) + "px"; t.style.top = (e.clientY - rect.top) + "px";
  t.textContent = text; t.style.opacity = 1;
}
function hideTooltip() { tooltip().style.opacity = 0; }

export function openChart(chartId) {
  setCurrentChartId(chartId);
  const chart = getCurrentChart();
  setCurrentClientId(chart.clientId);
  const client = getCurrentClient();

  document.getElementById("cn-name").textContent = client ? client.name : "—";
  const dateLabel = client ? formatDate(client.date) : "—";
  const timeLabel = chart.housesReliable ? `${client.time} (${client.tz || "zona s/d"})` : "hora desconocida";
  const ascText = chart.housesReliable ? ` · Ascendente en ${SIGN_NAMES_ES[signIndex(chart.ascLon)]} ${degToDM(chart.ascLon)}` : "";
  document.getElementById("cn-meta").textContent = `${dateLabel} · ${timeLabel} · ${client ? client.place : "—"}${ascText}`;
  document.getElementById("cn-houses-warning").style.display = chart.housesReliable ? "none" : "block";
  const engineNoteEl = document.getElementById("cn-engine-note");
  if (engineNoteEl) engineNoteEl.textContent = "Calculado con " + chart.engine + " · casas iguales (Equal House) desde el Ascendente real" + (chart.housesReliable ? "" : " · casas no confiables (hora desconocida)");

  showMinorBodies = true;
  document.getElementById("cn-minor-toggle").classList.add("active");
  renderWheel();
  renderPositionsTable();
  renderAspectPanel();
  renderAspectario();
  renderDecanTable();
  renderInterpretation();

  navigate("carta-natal");
}

function renderWheel() {
  const chart = getCurrentChart();
  const svg = document.getElementById("cn-wheel");
  svg.innerHTML = "";
  svg.appendChild(svgEl("circle", { cx: CX, cy: CY, r: R_ASPECT, fill: "#FBFBFC" }));
  for (let i = 0; i < 12; i++) svg.appendChild(svgEl("path", { d: wedgePath(i * 30, i * 30 + 30, R_ZODIAC_OUT, R_ZODIAC_IN), fill: ELEMENT_COLOR[ZODIAC_ELEMENTS[i]], opacity: 0.08 }));
  svg.appendChild(svgEl("circle", { cx: CX, cy: CY, r: R_ZODIAC_OUT, fill: "none", stroke: "#C9CBD4", "stroke-width": 1.2 }));
  svg.appendChild(svgEl("circle", { cx: CX, cy: CY, r: R_ZODIAC_IN, fill: "none", stroke: "#DCDEE5", "stroke-width": 1 }));
  if (showMinorBodies) svg.appendChild(svgEl("circle", { cx: CX, cy: CY, r: R_MINOR, fill: "none", stroke: "#E4E0EE", "stroke-width": 1, "stroke-dasharray": "1,2" }));
  svg.appendChild(svgEl("circle", { cx: CX, cy: CY, r: R_ASPECT, fill: "none", stroke: "#E4E5EA", "stroke-width": 1 }));

  for (let d = 0; d < 360; d += 5) {
    if (d % 30 === 0) continue;
    const isTen = d % 10 === 0;
    const p1 = toXY(d, R_ZODIAC_OUT), p2 = toXY(d, isTen ? R_TICK_OUT + 2 : R_TICK_OUT - 3);
    svg.appendChild(svgEl("line", { x1: p1.x, y1: p1.y, x2: p2.x, y2: p2.y, stroke: isTen ? "#8A8DA0" : "#B7BAC4", "stroke-width": isTen ? 1.1 : 0.6 }));
  }
  for (let i = 0; i < 12; i++) {
    const deg = i * 30;
    const p1 = toXY(deg, R_ZODIAC_IN), p2 = toXY(deg, R_TICK_OUT + 2);
    svg.appendChild(svgEl("line", { x1: p1.x, y1: p1.y, x2: p2.x, y2: p2.y, stroke: "#B0B3BE", "stroke-width": 1 }));
    const mid = toXY(deg + 15, (R_ZODIAC_OUT + R_ZODIAC_IN) / 2);
    const t = svgEl("text", { x: mid.x, y: mid.y + 5, "text-anchor": "middle", "font-size": 15, fill: ELEMENT_COLOR[ZODIAC_ELEMENTS[i]], "font-weight": "600" });
    t.textContent = ZODIAC_SIGNS[i]; svg.appendChild(t);
    for (let dec = 0; dec < 3; dec++) {
      const sd = i * 30 + dec * 10;
      const rp = toXY(sd + 5, R_ZODIAC_IN + 7);
      const rt = svgEl("text", { x: rp.x, y: rp.y + 2.5, "text-anchor": "middle", "font-size": 8, fill: "#9AA1B4", opacity: 0.85 });
      rt.textContent = DECAN_RULERS[i][dec]; svg.appendChild(rt);
    }
  }
  chart.houseCusps.forEach((deg, i) => {
    const isAngle = ANGLES.some(a => a.cuspIndex === i);
    if (isAngle) return;
    const p1 = toXY(deg, R_ASPECT), p2 = toXY(deg, R_HOUSE);
    svg.appendChild(svgEl("line", { x1: p1.x, y1: p1.y, x2: p2.x, y2: p2.y, stroke: "#1B2A4A", "stroke-width": 1, opacity: 0.35 }));
    const lp = toXY(deg + 9, R_ASPECT - 13);
    const lbl = svgEl("text", { x: lp.x, y: lp.y, "text-anchor": "middle", "font-size": 9, fill: "#9AA1B4" }); lbl.textContent = i + 1; svg.appendChild(lbl);
  });
  ANGLES.forEach(angle => {
    const deg = chart.houseCusps[angle.cuspIndex];
    const p1 = toXY(deg, R_ASPECT), p2 = toXY(deg, R_ANGLE_OUT);
    svg.appendChild(svgEl("line", { x1: p1.x, y1: p1.y, x2: p2.x, y2: p2.y, stroke: "#B8863B", "stroke-width": 2 }));
    const lp = toXY(deg, R_ANGLE_OUT + 12);
    const chipW = angle.label.length > 2 ? 26 : 22;
    svg.appendChild(svgEl("rect", { x: lp.x - chipW / 2, y: lp.y - 9, width: chipW, height: 16, rx: 4, fill: "#1B2A4A" }));
    const lbl = svgEl("text", { x: lp.x, y: lp.y + 3, "text-anchor": "middle", "font-size": 10, fill: "#F1D9A8", "font-weight": "600" }); lbl.textContent = angle.label; svg.appendChild(lbl);
    const dp = toXY(deg, R_ANGLE_OUT + 24);
    const dl = svgEl("text", { x: dp.x, y: dp.y + 2, "text-anchor": "middle", "font-size": 8, fill: "#8A8DA0" }); dl.textContent = degToDM(deg); svg.appendChild(dl);
  });
  chart.aspects.forEach(asp => {
    if (!asp.active) return;
    const isMinor = chart.positions[asp.a].minor || chart.positions[asp.b].minor;
    if (isMinor && !showMinorBodies) return;
    const isHovered = hoveredAspectId === asp.id;
    const isDimmed = hoveredAspectId !== null && !isHovered;
    const pa = toXY(chart.positions[asp.a].lon, R_ASPECT), pb = toXY(chart.positions[asp.b].lon, R_ASPECT);
    svg.appendChild(svgEl("line", {
      x1: pa.x, y1: pa.y, x2: pb.x, y2: pb.y, stroke: ASPECT_COLOR[asp.type],
      "stroke-width": isHovered ? ASPECT_WIDTH[asp.type] + 1.4 : (isMinor ? Math.max(ASPECT_WIDTH[asp.type] - 0.4, 0.8) : ASPECT_WIDTH[asp.type]),
      opacity: isDimmed ? 0.12 : (isHovered ? 1 : (isMinor ? 0.6 : 0.8)),
      "stroke-dasharray": isMinor ? "3,2" : ASPECT_DASH[asp.type]
    }));
  });
  Object.entries(chart.positions).forEach(([name, data]) => {
    if (data.minor) return;
    const pos = toXY(data.lon, R_PLANET); const color = PLANET_COLOR[name] || "#1B2A4A";
    const g = svgEl("g", { style: "cursor:pointer" });
    g.appendChild(svgEl("circle", { cx: pos.x, cy: pos.y, r: 12, fill: "#FFFFFF", stroke: color, "stroke-width": 1.4 }));
    const gl = svgEl("text", { x: pos.x, y: pos.y + 4.5, "text-anchor": "middle", "font-size": 13.5, fill: color }); gl.textContent = data.glyph; g.appendChild(gl);
    if (data.retrograde) { const rx = svgEl("text", { x: pos.x + 10, y: pos.y - 8, "text-anchor": "middle", "font-size": 8, fill: "#B3462C", "font-weight": "700" }); rx.textContent = "℞"; g.appendChild(rx); }
    const dp = toXY(data.lon, R_PLANET - 17);
    const dl = svgEl("text", { x: dp.x, y: dp.y + 2.5, "text-anchor": "middle", "font-size": 7.5, fill: "#6B7280" }); dl.textContent = Math.floor(data.lon % 30) + "°"; g.appendChild(dl);
    const decan = getDecan(data.lon);
    g.addEventListener("mousemove", (e) => showTooltip(e, `${data.glyph} ${bodyLabel(name)} · ${data.sign} ${degToDM(data.lon)} · Casa ${data.house}${data.retrograde ? " · retrógrado ℞" : ""} · decanato ${decan.decanNum} (${RULER_NAME[decan.ruler]})`));
    g.addEventListener("mouseleave", hideTooltip);
    svg.appendChild(g);
  });
  if (showMinorBodies) {
    Object.entries(chart.positions).forEach(([name, data]) => {
      if (!data.minor) return;
      const pos = toXY(data.lon, R_MINOR); const color = PLANET_COLOR[name] || "#6B5B95";
      const g = svgEl("g", { style: "cursor:pointer" });
      g.appendChild(svgEl("rect", { x: pos.x - 9, y: pos.y - 9, width: 18, height: 18, rx: 4, fill: "#FFFFFF", stroke: color, "stroke-width": 1.1, "stroke-dasharray": "2,1.4" }));
      const gl = svgEl("text", { x: pos.x, y: pos.y + 3.5, "text-anchor": "middle", "font-size": 9, fill: color, "font-weight": "600" }); gl.textContent = data.glyph; g.appendChild(gl);
      g.addEventListener("mousemove", (e) => { const decan = getDecan(data.lon); showTooltip(e, `${data.glyph} ${data.fullName} · ${data.sign} ${degToDM(data.lon)} · Casa ${data.house} · decanato ${decan.decanNum} (${RULER_NAME[decan.ruler]})`); });
      g.addEventListener("mouseleave", hideTooltip);
      svg.appendChild(g);
    });
  }
  renderLegend();
}

function renderLegend() {
  const legend = document.getElementById("cn-legend"); legend.innerHTML = "";
  legend.innerHTML += `<span><span class="swatch" style="background:#B8863B"></span>ASC · IC · DSC · MC</span>`;
  if (showMinorBodies) legend.innerHTML += `<span><span class="swatch" style="background:#6B5B95;height:8px;width:8px;border-radius:3px;"></span>Cuerpos menores</span>`;
  ["conjunction", "sextile", "square", "opposition"].forEach(type => {
    legend.innerHTML += `<span><span class="swatch" style="background:${ASPECT_COLOR[type]}"></span>${ASPECT_LABEL[type]}</span>`;
  });
}

function renderPositionsTable() {
  const chart = getCurrentChart();
  const tbody = document.getElementById("cn-positions-table");
  tbody.innerHTML = "";
  const main = Object.entries(chart.positions).filter(([, d]) => !d.minor);
  const minor = Object.entries(chart.positions).filter(([, d]) => d.minor);

  if (chart.housesReliable) {
    const ascSign = SIGN_NAMES_ES[signIndex(chart.ascLon)];
    const mcSign = SIGN_NAMES_ES[signIndex(chart.mcLon)];
    tbody.innerHTML += `<tr><td class="glyph" style="color:var(--brass);font-family:'IBM Plex Mono',monospace;font-size:11px;">ASC</td><td>Ascendente</td><td>${ascSign} ${degToDM(chart.ascLon)}</td><td class="mono">1</td></tr>`;
    tbody.innerHTML += `<tr><td class="glyph" style="color:var(--brass);font-family:'IBM Plex Mono',monospace;font-size:11px;">MC</td><td>Medio Cielo</td><td>${mcSign} ${degToDM(chart.mcLon)}</td><td class="mono">10</td></tr>`;
    tbody.innerHTML += `<tr><td colspan="4" style="padding-top:4px;padding-bottom:4px;border-bottom:1px solid var(--line);"></td></tr>`;
  }
  main.forEach(([name, data]) => {
    const color = PLANET_COLOR[name] || "#1B2A4A";
    tbody.innerHTML += `<tr><td class="glyph" style="color:${color};">${data.glyph}</td><td>${bodyLabel(name)}</td><td>${data.sign} ${degToDM(data.lon)}${data.retrograde ? ' <span style="color:#B3462C">℞</span>' : ''}</td><td class="mono">${data.house}</td></tr>`;
  });
  tbody.innerHTML += `<tr><td colspan="4" style="padding-top:10px;padding-bottom:4px;border-bottom:1px solid var(--line);font-size:10px;text-transform:uppercase;color:var(--text-muted);">Asteroides y centauros</td></tr>`;
  minor.forEach(([name, data]) => {
    const color = PLANET_COLOR[name] || "#6B5B95";
    tbody.innerHTML += `<tr><td class="glyph mono" style="color:${color};font-size:11px;">${data.glyph}</td><td>${data.fullName}</td><td>${data.sign} ${degToDM(data.lon)}</td><td class="mono">${data.house}</td></tr>`;
  });
}

function renderAspectPanel() {
  const chart = getCurrentChart();
  const mainList = document.getElementById("cn-aspect-list-main");
  const minorList = document.getElementById("cn-aspect-list-minor");
  mainList.innerHTML = ""; minorList.innerHTML = "";
  [...chart.aspects].sort((a, b) => a.orb - b.orb).forEach(asp => {
    const bodyA = chart.positions[asp.a], bodyB = chart.positions[asp.b];
    const isMinor = bodyA.minor || bodyB.minor;
    const maxOrb = ORB_TABLE[asp.type][1];
    const strength = Math.max(0, Math.min(1, 1 - asp.orb / maxOrb));
    const applying = isApplying(chart.positions, asp.a, asp.b, asp.type);
    const days = daysToExact(chart.positions, asp);
    let daysText = "";
    if (days !== null) daysText = applying ? (days === 0 ? "exacto hoy" : `faltan ~${days} d.`) : `hace ~${days} d.`;
    const row = document.createElement("div");
    row.className = "aspect-row" + (asp.active ? "" : " inactive");
    row.innerHTML = `
      <input type="checkbox" class="aspect-toggle" ${asp.active ? "checked" : ""}>
      <span class="glyph-pair"><span style="color:${PLANET_COLOR[asp.a] || (bodyA.minor ? '#6B5B95' : '#1B2A4A')}">${bodyA.glyph}</span> ${ASPECT_GLYPH[asp.type]} <span style="color:${PLANET_COLOR[asp.b] || (bodyB.minor ? '#6B5B95' : '#1B2A4A')}">${bodyB.glyph}</span></span>
      <span class="aspect-names">${bodyLabel(asp.a)} – ${bodyLabel(asp.b)}<span class="aspect-gloss">${aspectGloss(asp, bodyLabel)}</span></span>
      <div class="aspect-meta">
        <span class="aspect-type ${asp.type}">${ASPECT_LABEL[asp.type]}</span>
        <span class="aspect-motion ${applying ? 'applying' : ''}">${applying ? '↗' : '↘'}${daysText ? ' ' + daysText : ''}</span>
        <span class="aspect-orb mono">${asp.orb.toFixed(1)}°</span>
      </div>`;
    row.querySelector(".aspect-toggle").addEventListener("change", (e) => { asp.active = e.target.checked; row.classList.toggle("inactive", !asp.active); renderWheel(); });
    row.addEventListener("mouseenter", () => { hoveredAspectId = asp.id; renderWheel(); });
    row.addEventListener("mouseleave", () => { hoveredAspectId = null; renderWheel(); });
    (isMinor ? minorList : mainList).appendChild(row);
  });
  if (!mainList.children.length) mainList.innerHTML = `<div style="font-size:12px;color:var(--text-muted);">Sin aspectos entre planetas dentro del orbe.</div>`;
  if (!minorList.children.length) minorList.innerHTML = `<div style="font-size:12px;color:var(--text-muted);">Sin aspectos con cuerpos menores dentro del orbe.</div>`;
  renderPatterns();
}

function activeType(chart, a, b) { const f = chart.aspects.find(x => x.active && ((x.a === a && x.b === b) || (x.a === b && x.b === a))); return f ? f.type : null; }
function renderPatterns() {
  const chart = getCurrentChart();
  const wrap = document.getElementById("cn-patterns");
  const patterns = [];
  const mainBodies = Object.keys(chart.positions).filter(n => !chart.positions[n].minor);
  chart.aspects.filter(x => x.active && x.type === "opposition").forEach(opp => {
    mainBodies.forEach(apex => {
      if (apex === opp.a || apex === opp.b) return;
      if (activeType(chart, apex, opp.a) === "square" && activeType(chart, apex, opp.b) === "square") {
        patterns.push({ icon: "T", title: `T-cuadrado: ${bodyLabel(opp.a)} – ${bodyLabel(opp.b)}, vértice en ${bodyLabel(apex)}`, sub: "Punto de mayor acción de la carta." });
      }
    });
  });
  for (let i = 0; i < mainBodies.length; i++) for (let j = i + 1; j < mainBodies.length; j++) for (let k = j + 1; k < mainBodies.length; k++) {
    const [x, y, z] = [mainBodies[i], mainBodies[j], mainBodies[k]];
    if (activeType(chart, x, y) === "trine" && activeType(chart, y, z) === "trine" && activeType(chart, x, z) === "trine") {
      patterns.push({ icon: "△", title: `Gran Trígono: ${bodyLabel(x)} – ${bodyLabel(y)} – ${bodyLabel(z)}`, sub: "Circuito de flujo armónico entre los tres." });
    }
  }
  const byHouse = {};
  mainBodies.forEach(n => { if (chart.positions[n].house !== "—") { (byHouse[chart.positions[n].house] ??= []).push(n); } });
  Object.entries(byHouse).forEach(([house, list]) => {
    if (list.length >= 3) patterns.push({ icon: "●", title: `Stellium en Casa ${house}: ${list.map(bodyLabel).join(", ")}`, sub: "Concentración de energía en esta área de vida." });
  });
  wrap.innerHTML = patterns.length ? "" : `<div class="pattern-empty">No se detectaron configuraciones mayores con los aspectos activos.</div>`;
  patterns.forEach(p => {
    const card = document.createElement("div"); card.className = "pattern-card";
    card.innerHTML = `<div class="pattern-icon">${p.icon}</div><div><div class="pattern-title">${p.title}</div><div class="pattern-sub">${p.sub}</div></div>`;
    wrap.appendChild(card);
  });
}

function renderAspectario() {
  const chart = getCurrentChart();
  const table = document.getElementById("cn-aspectario-table");
  const names = Object.keys(chart.positions);
  let head = "<tr><th></th>" + names.map(n => `<th>${chart.positions[n].glyph}</th>`).join("") + "</tr>";
  let body = names.map(rowName => {
    let cells = `<th>${chart.positions[rowName].glyph}</th>`;
    names.forEach(colName => {
      if (rowName === colName) { cells += `<td style="background:#F7F7F9;"></td>`; return; }
      const tight = chart.positions[rowName].minor || chart.positions[colName].minor;
      const type = findAspect(chart.positions[rowName].lon, chart.positions[colName].lon, tight);
      cells += type ? `<td title="${ASPECT_LABEL[type]}"><span style="color:${ASPECT_COLOR[type]}">${ASPECT_GLYPH[type]}</span></td>` : `<td></td>`;
    });
    return `<tr>${cells}</tr>`;
  }).join("");
  table.innerHTML = head + body;
}

function renderDecanTable() {
  const chart = getCurrentChart();
  const tbody = document.getElementById("cn-decan-table");
  const main = Object.entries(chart.positions).filter(([, d]) => !d.minor);
  const minor = Object.entries(chart.positions).filter(([, d]) => d.minor);
  tbody.innerHTML = "";
  [...main, ...minor].forEach(([name, data]) => {
    const decan = getDecan(data.lon);
    const color = PLANET_COLOR[name] || (data.minor ? "#6B5B95" : "#1B2A4A");
    tbody.innerHTML += `<tr>
      <td class="glyph" style="color:${color};${data.minor ? "font-family:'IBM Plex Mono',monospace;font-size:11px;" : ""}">${data.glyph}</td>
      <td>${bodyLabel(name)}</td><td>${data.sign} ${degToDM(data.lon)}</td>
      <td>${decan.decanNum}º decanato <span class="mono" style="color:var(--text-muted);">(${decan.rangeStart}°–${decan.rangeEnd}°)</span></td>
      <td>${decan.ruler} ${RULER_NAME[decan.ruler]}</td></tr>`;
  });
}

function renderInterpretation() {
  const chart = getCurrentChart();
  const client = getCurrentClient();
  const panel = document.getElementById("cn-panel-interpretacion");
  if (chart.interpGenerated) { renderInterpretationText(); return; }
  panel.innerHTML = `
    <div class="block" style="text-align:center;padding:34px 22px;">
      <div style="font-size:13px;color:var(--text-muted);margin-bottom:14px;">
        Todavía no se generó la interpretación con IA para la carta de <b style="color:var(--navy-deep);">${client.name}</b>.
      </div>
      <button class="btn btn-primary" id="cn-gen-interp-btn">Generar interpretación con IA</button>
    </div>`;
  document.getElementById("cn-gen-interp-btn").addEventListener("click", async function () {
    this.textContent = "Generando..."; this.disabled = true;
    try {
      const { text } = generateInterpretation(chart, client);
      await saveInterpretation(chart.id, text);
      renderInterpretationText();
    } catch (err) {
      this.textContent = "Generar interpretación con IA"; this.disabled = false;
      alert("No se pudo guardar la interpretación: " + err.message);
    }
  });
}
function renderInterpretationText() {
  const chart = getCurrentChart(); const client = getCurrentClient();
  const panel = document.getElementById("cn-panel-interpretacion");
  const text = chart.interpText || generateInterpretation(chart, client).text;
  panel.innerHTML = `
    <div class="progress-note" style="font-size:12px;color:var(--text-muted);margin-bottom:14px;"><b>0/1</b> bloques aprobados · borrador recién generado</div>
    <div class="block">
      <div class="block-head"><h3>Síntesis inicial</h3><div><span class="ai-badge">Generado con IA</span></div></div>
      <p>${text}</p>
    </div>`;
}

export function initNatalChartComponent() {
  document.getElementById("cn-minor-toggle").addEventListener("click", function () {
    showMinorBodies = !showMinorBodies;
    this.classList.toggle("active", showMinorBodies);
    renderWheel();
  });
  document.querySelectorAll(".tab").forEach(tab => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
      document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));
      tab.classList.add("active");
      document.getElementById("cn-panel-" + tab.dataset.tab).classList.add("active");
    });
  });
}
