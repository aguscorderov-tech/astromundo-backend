// /components/NewChartForm.js
import { getClients, fetchClients, createClient, updateClient, findClient } from "../services/clientService.js";
import { createChartForClient } from "../services/natalChartService.js";
import { initSearchBox, getSelectedPlace, focusPlaceInput } from "./SearchBox.js";
import { openChart } from "./NatalChart.js";

export async function renderNuevaCartaForm() {
  await fetchClients();
  const sel = document.getElementById("nc-client-select");
  sel.innerHTML = `<option value="new">+ Cliente nuevo</option>` + getClients().map(c => `<option value="${c.id}">${c.name}</option>`).join("");
  sel.value = "new";
  document.getElementById("nc-new-client-field").style.display = "block";
  document.getElementById("nc-client-name").value = "";
}

export function initNewChartFormComponent() {
  initSearchBox();

  document.getElementById("nc-client-select").addEventListener("change", function () {
    document.getElementById("nc-new-client-field").style.display = this.value === "new" ? "block" : "none";
  });

  document.querySelectorAll("#nc-type-options .type-option").forEach(opt => {
    opt.addEventListener("click", () => {
      document.querySelectorAll("#nc-type-options .type-option").forEach(o => o.classList.remove("selected"));
      opt.classList.add("selected");
    });
  });

  const ncTimeUnknown = document.getElementById("nc-time-unknown");
  const ncTimeInput = document.getElementById("nc-time");
  ncTimeUnknown.addEventListener("change", () => {
    ncTimeInput.disabled = ncTimeUnknown.checked;
    ncTimeInput.style.opacity = ncTimeUnknown.checked ? 0.4 : 1;
    document.getElementById("nc-unknown-note").classList.toggle("visible", ncTimeUnknown.checked);
  });

  document.getElementById("nc-calc-btn").addEventListener("click", async () => {
    const btn = document.getElementById("nc-calc-btn");
    const selEl = document.getElementById("nc-client-select");
    const isNew = selEl.value === "new";
    const date = document.getElementById("nc-date").value;
    const timeUnknown = document.getElementById("nc-time-unknown").checked;
    const time = timeUnknown ? "" : document.getElementById("nc-time").value;

    const place = getSelectedPlace();
    if (!place) {
      alert("Elegí el lugar de nacimiento de la lista de sugerencias (o cargá coordenadas manuales) antes de calcular la carta — si no, el Ascendente no se puede calcular con precisión.");
      focusPlaceInput();
      return;
    }

    const birthFields = { date, time, timeUnknown, place: place.name, lat: place.lat, lng: place.lng, tz: place.tz, tzName: place.tzName };

    const originalLabel = btn.textContent;
    btn.disabled = true;
    btn.textContent = "Calculando...";
    try {
      let client;
      if (isNew) {
        const name = document.getElementById("nc-client-name").value.trim() || "Cliente sin nombre";
        client = await createClient({ name, ...birthFields });
      } else {
        client = (await updateClient(selEl.value, birthFields)) || findClient(selEl.value);
      }
      const chart = await createChartForClient(client);
      openChart(chart.id);
    } catch (err) {
      alert("No se pudo calcular/guardar la carta: " + err.message);
    } finally {
      btn.disabled = false;
      btn.textContent = originalLabel;
    }
  });
}
