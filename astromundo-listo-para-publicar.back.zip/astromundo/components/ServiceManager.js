// /components/ServiceManager.js
import { getServices, fetchServices, createService, updateService, toggleService, removeService } from "../services/paymentService.js";

const MODALITY_LABEL = { async: "Informe async", video: "Videollamada", presencial: "Presencial" };
const MODALITY_ICON = { async: "◐", video: "☉", presencial: "📍" };
let editingServiceId = null;

export async function loadServicesView() {
  await fetchServices();
  renderServices();
}

export function renderServices() {
  const list = document.getElementById("services-list");
  const SERVICES = getServices();
  list.innerHTML = "";
  if (!SERVICES.length) {
    list.innerHTML = `<div style="font-size:13px;color:var(--text-muted);">Todavía no cargaste ningún servicio.</div>`;
    return;
  }
  SERVICES.forEach(s => {
    const card = document.createElement("div");
    card.className = "service-card" + (s.active ? "" : " inactive");
    card.innerHTML = `
      <div class="service-icon">${MODALITY_ICON[s.modality]}</div>
      <div class="service-main">
        <h3>${s.name}</h3>
        <div class="service-meta"><span>${s.desc}</span></div>
        <div class="service-meta" style="margin-top:4px;">
          <span>${MODALITY_LABEL[s.modality]}</span>
          ${s.duration ? `<span>· ${s.duration} min</span>` : ""}
          ${!s.active ? `<span style="color:var(--rust);">· Pausado</span>` : ""}
        </div>
      </div>
      <div class="service-price">$${s.price.toLocaleString("es-AR")}</div>
      <div class="service-actions">
        <button data-action="toggle">${s.active ? "Pausar" : "Activar"}</button>
        <button data-action="edit">Editar</button>
        <button data-action="delete" class="danger">Quitar</button>
      </div>
    `;
    card.querySelector('[data-action="toggle"]').addEventListener("click", async () => { await toggleService(s.id); renderServices(); });
    card.querySelector('[data-action="edit"]').addEventListener("click", () => openServiceForm(s));
    card.querySelector('[data-action="delete"]').addEventListener("click", async () => {
      if (confirm(`¿Quitar "${s.name}" de tus servicios?`)) { await removeService(s.id); renderServices(); }
    });
    list.appendChild(card);
  });
}

function openServiceForm(service) {
  editingServiceId = service ? service.id : null;
  document.getElementById("svc-form-title").textContent = service ? "Editar servicio" : "Nuevo servicio";
  document.getElementById("svc-name").value = service ? service.name : "";
  document.getElementById("svc-desc").value = service ? service.desc : "";
  document.getElementById("svc-duration").value = service && service.duration ? service.duration : "";
  document.getElementById("svc-price").value = service ? service.price : "";
  const mod = service ? service.modality : "async";
  document.querySelectorAll("#svc-modality-options .modality-option").forEach(o => o.classList.toggle("selected", o.dataset.mod === mod));
  document.getElementById("svc-duration-field").style.display = mod === "async" ? "none" : "block";
  document.getElementById("svc-form-panel").style.display = "block";
  document.getElementById("svc-name").focus();
}

export function initServiceManagerComponent() {
  document.getElementById("svc-new-btn").addEventListener("click", () => openServiceForm(null));
  document.getElementById("svc-cancel-btn").addEventListener("click", () => { document.getElementById("svc-form-panel").style.display = "none"; });
  document.querySelectorAll("#svc-modality-options .modality-option").forEach(opt => {
    opt.addEventListener("click", () => {
      document.querySelectorAll("#svc-modality-options .modality-option").forEach(o => o.classList.remove("selected"));
      opt.classList.add("selected");
      document.getElementById("svc-duration-field").style.display = opt.dataset.mod === "async" ? "none" : "block";
    });
  });
  document.getElementById("svc-save-btn").addEventListener("click", async () => {
    const name = document.getElementById("svc-name").value.trim();
    if (!name) { alert("Ponele un nombre al servicio."); return; }
    const price = parseInt(document.getElementById("svc-price").value, 10) || 0;
    const modality = document.querySelector("#svc-modality-options .modality-option.selected").dataset.mod;
    const duration = modality === "async" ? null : (parseInt(document.getElementById("svc-duration").value, 10) || null);
    const desc = document.getElementById("svc-desc").value.trim();

    try {
      if (editingServiceId) {
        await updateService(editingServiceId, { name, desc, modality, duration, price });
      } else {
        await createService({ name, desc, modality, duration, price });
      }
      document.getElementById("svc-form-panel").style.display = "none";
      renderServices();
    } catch (err) {
      alert("No se pudo guardar el servicio: " + err.message);
    }
  });
}
