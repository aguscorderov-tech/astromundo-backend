// /app.js
// Composition root. Ahora con sesión real: no se muestra nada de la app
// hasta que hay un login válido contra el backend.

import { initAuthComponent, tryRestoreSession } from "./components/Auth.js";
import { initRouter, registerView, navigate } from "./components/Router.js";
import { renderDashboard } from "./components/Dashboard.js";
import { renderAgenda, initCalendarComponent } from "./components/Calendar.js";
import { loadClientsView, initClientListComponent } from "./components/ClientList.js";
import { renderCartasGrid } from "./components/ChartGallery.js";
import { loadServicesView, initServiceManagerComponent } from "./components/ServiceManager.js";
import { renderPagos } from "./components/PaymentUI.js";
import { renderNuevaCartaForm, initNewChartFormComponent } from "./components/NewChartForm.js";
import { initNatalChartComponent } from "./components/NatalChart.js";

let wired = false;

function enterApp() {
  document.getElementById("app-sidebar").style.display = "flex";
  if (!wired) {
    // El wiring de eventos (listeners de botones, etc.) se hace una sola vez.
    registerView("panel", renderDashboard);
    registerView("agenda", renderAgenda);
    registerView("clientes", loadClientsView);
    registerView("cartas", renderCartasGrid);
    registerView("servicios", loadServicesView);
    registerView("nueva-carta", renderNuevaCartaForm);
    registerView("pagos", renderPagos);

    initCalendarComponent();
    initClientListComponent();
    initServiceManagerComponent();
    initNewChartFormComponent();
    initNatalChartComponent();
    initRouter();
    wired = true;
  }
  navigate("panel");
}

async function bootstrap() {
  initAuthComponent(enterApp);
  const restored = await tryRestoreSession();
  if (restored) enterApp();
  // si no hay sesión, se queda en la vista de login (ya es la vista activa por defecto)
}

document.addEventListener("DOMContentLoaded", bootstrap);
