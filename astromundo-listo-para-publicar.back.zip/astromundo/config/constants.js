// /config/constants.js
// Constantes de negocio y de UI que no pertenecen a un dominio específico.
// Los orbes/ángulos astrológicos NO van acá — esos son constantes de dominio
// y viven en astrology-engine/aspects.js.

export const BRAND_NAME = "Astromundo";

export const WEEKDAY_LABELS = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"];

export const PLANS = {
  gratis:  { name: "Gratis",  price: 0,     commission: null },
  pro:     { name: "Pro",     price: 30000, commission: 0.045 },
  premium: { name: "Premium", price: 68000, commission: 0.025 },
};

// Semana de referencia usada para las fechas de ejemplo del calendario de agenda.
export const AGENDA_REFERENCE_MONDAY_UTC = [2026, 7, 3]; // [año, mes(0-index), día] — lunes 3 ago 2026
