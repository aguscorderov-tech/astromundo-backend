// /config/apiKeys.js
// Hoy la app no necesita ninguna API key: astronomy-engine corre 100% en el
// navegador y la búsqueda de lugares usa Open-Meteo, que es pública y sin key.
//
// Este archivo queda preparado para cuando se conecten servicios que sí la
// requieran (ej. Mercado Pago para cobros reales, un proveedor de SMS/email
// para notificaciones). En producción estos valores NUNCA deben vivir en un
// archivo del frontend — deben salir de variables de entorno del backend.

export const API_KEYS = {
  mercadoPago: null,   // pendiente: integración de cobros real
  emailProvider: null, // pendiente: notificaciones de turnos
};
