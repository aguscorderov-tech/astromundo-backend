// /config/settings.js
// Valores por defecto que un astrólogo podría eventualmente cambiar desde una
// pantalla de configuración — separados de las constantes fijas de negocio.

export const SETTINGS = {
  agenda: {
    startHour: 9,
    endHour: 19,
  },
  chart: {
    houseSystem: "equal", // "equal" (implementado) — Placidus queda para una iteración futura
    defaultTimezone: "America/Argentina/Buenos_Aires",
  },
  currency: "ARS",
  locale: "es-AR",
};
