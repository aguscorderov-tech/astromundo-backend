// /config/environment.js
// Todo lo que depende de "dónde corre la app" vive acá — nunca hardcodeado
// en un motor o un componente.

export const ENV = {
  // La librería de efemérides se carga por <script> clásico en index.html
  // (no como módulo ES) porque su build UMD expone un global `window.Astronomy`.
  ASTRONOMY_ENGINE_CDN: "https://cdn.jsdelivr.net/npm/astronomy-engine@2.1.19/astronomy.browser.min.js",
};

// true si astronomy-engine cargó correctamente (requiere internet la primera vez).
// Si es false, astrology-engine/ephemeris.js cae a una aproximación de respaldo.
export function hasRealEphemeris() {
  return typeof Astronomy !== "undefined";
}
