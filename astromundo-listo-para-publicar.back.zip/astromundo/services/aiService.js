// /services/aiService.js
// Genera el borrador de interpretación en base a la carta calculada. Hoy es
// una plantilla simple (Sol + Luna + Ascendente + aspecto más ajustado) — el
// diseño completo del sistema de prompts (con plantillas por escuela
// astrológica, orbe reducido para cuerpos menores, etc.) está documentado en
// /docs/sistema-prompts-ia.md para cuando esto se conecte a un LLM real.

import { PLANET_KEYWORD, ASPECT_LABEL, SIGN_NAMES_ES, signIndex } from "../astrology-engine/index.js";
import { bodyLabel } from "./natalChartService.js";

/**
 * Genera el bloque de "síntesis inicial" para una carta+cliente.
 * @returns {object} { sunSign, moonSign, ascText, aspectText, clientName }
 * NatalChart.js decide el HTML — acá solo se arma el contenido.
 */
export function generateInterpretation(chart, client) {
  const sunSign = chart.positions.sun.sign;
  const moonSign = chart.positions.moon.sign;
  const ascText = chart.housesReliable ? `y el Ascendente en ${SIGN_NAMES_ES[signIndex(chart.ascLon)]} ` : "";

  const topAspects = [...chart.aspects].sort((a, b) => a.orb - b.orb).slice(0, 2);
  let aspectText = "";
  if (topAspects.length) {
    aspectText = " El aspecto más ajustado de la carta es " +
      topAspects.map(a => `${bodyLabel(a.a)} ${ASPECT_LABEL[a.type].toLowerCase()} ${bodyLabel(a.b)}`).join(" y ") +
      ", que conviene mirar de cerca en la lectura.";
  }

  const text = `Con el Sol en ${sunSign} y la Luna en ${moonSign} ${ascText}— ${client.name} combina una necesidad de ${PLANET_KEYWORD.sun} con una forma de procesar desde ${PLANET_KEYWORD.moon}.${aspectText} Este es un primer borrador automático: conviene revisarlo y ajustarlo antes de enviarlo.`;

  return { sunSign, moonSign, text };
}
