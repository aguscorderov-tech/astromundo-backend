// /services/apiClient.js
// Único punto de contacto con el backend real. Todos los demás servicios
// (clientService, natalChartService, etc.) pasan por acá — así el día que
// cambie la URL del backend, o la forma de autenticar, se toca un solo archivo.

const TOKEN_KEY = "astromundo_token";

// En desarrollo local el backend corre en :3001. En producción, definir
// window.ASTROMUNDO_API_URL antes de cargar app.js (por ejemplo desde
// index.html) apuntando al backend ya desplegado.
export const API_BASE_URL =
  (typeof window !== "undefined" && window.ASTROMUNDO_API_URL) || "http://localhost:3001/api";

export function getToken() {
  try { return localStorage.getItem(TOKEN_KEY); } catch (e) { return null; }
}
export function setToken(token) {
  try { localStorage.setItem(TOKEN_KEY, token); } catch (e) { /* almacenamiento no disponible */ }
}
export function clearToken() {
  try { localStorage.removeItem(TOKEN_KEY); } catch (e) { /* no-op */ }
}

export class ApiError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

async function request(method, path, body) {
  const headers = { "Content-Type": "application/json" };
  const token = getToken();
  if (token) headers["Authorization"] = "Bearer " + token;

  const res = await fetch(API_BASE_URL + path, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  let data = null;
  try { data = await res.json(); } catch (e) { /* respuesta sin body (ej. 204) */ }

  if (!res.ok) {
    if (res.status === 401) clearToken(); // sesión vencida o inválida — se limpia sola
    throw new ApiError(res.status, (data && data.error) || `Error ${res.status}`);
  }
  return data;
}

export const api = {
  get: (path) => request("GET", path),
  post: (path, body) => request("POST", path, body),
  put: (path, body) => request("PUT", path, body),
  del: (path) => request("DELETE", path),
};
