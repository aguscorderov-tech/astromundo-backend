// /services/userService.js
// Perfil y sesión del astrólogo. Este es el archivo que dijimos que iba a
// cambiar el día que hubiera autenticación real — ningún componente necesitó
// tocarse en su forma de pedir "quién es el usuario actual", solo cambió
// de dónde sale la respuesta (antes un objeto fijo, ahora el backend).

import { api, setToken, clearToken, getToken } from "./apiClient.js";
import { PLANS } from "../config/constants.js";

let currentUser = null; // se completa al hacer login o al restaurar sesión

export function isAuthenticated() {
  return !!getToken();
}

export function getCurrentUser() {
  return currentUser;
}

export function getCurrentPlan() {
  return PLANS[(currentUser && currentUser.plan) || "gratis"];
}

export async function register({ email, password, name }) {
  const { token, user } = await api.post("/auth/register", { email, password, name });
  setToken(token);
  currentUser = user;
  return user;
}

export async function login({ email, password }) {
  const { token, user } = await api.post("/auth/login", { email, password });
  setToken(token);
  currentUser = user;
  return user;
}

export function logout() {
  clearToken();
  currentUser = null;
}

// Se llama al arrancar la app: si hay un token guardado de una sesión
// anterior, confirma que sigue siendo válido y recupera el perfil.
export async function restoreSession() {
  if (!getToken()) return null;
  try {
    currentUser = await api.get("/auth/me");
    return currentUser;
  } catch (e) {
    clearToken();
    return null;
  }
}
