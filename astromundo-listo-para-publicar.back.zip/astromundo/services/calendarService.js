// /services/calendarService.js
// Mismo patrón que clientService: caché local + funciones async que pegan
// al backend y la actualizan.

import { api } from "./apiClient.js";

let APPOINTMENTS = [];
let agendaWeekOffset = 0; // 0 = semana actual — la única con turnos reales por ahora

function hydrate(row) {
  return { id: row.id, clientId: row.client_id, serviceId: row.service_id, chartId: row.chart_id, day: row.day, time: row.time, status: row.status };
}

export async function fetchAppointments() {
  const rows = await api.get("/appointments");
  APPOINTMENTS = rows.map(hydrate);
  return APPOINTMENTS;
}

export function getAppointments() {
  return APPOINTMENTS;
}

export function findAppointment(id) {
  return APPOINTMENTS.find(a => a.id === id);
}

export async function createAppointment(data) {
  const row = await api.post("/appointments", data);
  const appt = hydrate(row);
  APPOINTMENTS = [...APPOINTMENTS, appt];
  return appt;
}

export async function updateAppointment(id, data) {
  const row = await api.put(`/appointments/${id}`, data);
  const appt = hydrate(row);
  APPOINTMENTS = APPOINTMENTS.map(a => (a.id === id ? appt : a));
  return appt;
}

export function getAgendaWeekOffset() {
  return agendaWeekOffset;
}

export function shiftAgendaWeek(delta) {
  agendaWeekOffset += delta;
  return agendaWeekOffset;
}

export function countAppointmentsByDay() {
  const counts = [0, 0, 0, 0, 0, 0, 0];
  APPOINTMENTS.forEach(a => counts[a.day]++);
  return counts;
}
