// /services/clientService.js
// Antes: un array en memoria. Ahora: una caché local que se llena pidiéndole
// datos al backend, más funciones de escritura que pegan a la API y
// actualizan esa caché. Los componentes que solo necesitan LEER (getClients,
// findClient) siguen siendo síncronos — evita tener que volver async cada
// función de cada componente. Los que ESCRIBEN (createClient, updateClient)
// son async porque dependen de la respuesta real del servidor.

import { api } from "./apiClient.js";

let CLIENTS = [];
let currentClientId = null;

export async function fetchClients() {
  CLIENTS = await api.get("/clients");
  return CLIENTS;
}

export function getClients() {
  return CLIENTS;
}

export function findClient(id) {
  return CLIENTS.find(c => c.id === id);
}

export function getCurrentClient() {
  return findClient(currentClientId);
}

export function setCurrentClientId(id) {
  currentClientId = id;
}

export async function createClient(data) {
  const client = await api.post("/clients", data);
  CLIENTS = [client, ...CLIENTS];
  return client;
}

export async function updateClient(id, data) {
  const client = await api.put(`/clients/${id}`, data);
  CLIENTS = CLIENTS.map(c => (c.id === id ? client : c));
  return client;
}

export function formatDate(iso) {
  if (!iso) return "—";
  const months = ["ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic"];
  const [y, m, d] = iso.split("-");
  return `${parseInt(d, 10)} ${months[parseInt(m, 10) - 1]} ${y}`;
}
