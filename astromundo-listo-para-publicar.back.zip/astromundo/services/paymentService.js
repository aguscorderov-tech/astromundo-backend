// /services/paymentService.js
// Dos responsabilidades: el catálogo de SERVICIOS (con caché local + API) y
// los MOVIMIENTOS de pago, que ahora se piden directo al backend ya
// resumidos (el cálculo de comisión lo hace el servidor, con la comisión
// real del plan del astrólogo — ver /api/payments/summary).

import { api } from "./apiClient.js";

let SERVICES = [];

function hydrateService(row) {
  return {
    id: row.id, name: row.name, desc: row.description, modality: row.modality,
    duration: row.duration_minutes, price: row.price_cents, active: !!row.is_active,
  };
}

export async function fetchServices() {
  const rows = await api.get("/services");
  SERVICES = rows.map(hydrateService);
  return SERVICES;
}

export function getServices() {
  return SERVICES;
}
export function getActiveServices() {
  return SERVICES.filter(s => s.active);
}
export function findService(id) {
  return SERVICES.find(s => s.id === id);
}

export async function createService(data) {
  const row = await api.post("/services", data);
  const service = hydrateService(row);
  SERVICES = [...SERVICES, service];
  return service;
}

export async function updateService(id, data) {
  const row = await api.put(`/services/${id}`, data);
  const service = hydrateService(row);
  SERVICES = SERVICES.map(s => (s.id === id ? service : s));
  return service;
}

export async function toggleService(id) {
  const row = await api.post(`/services/${id}/toggle`);
  const service = hydrateService(row);
  SERVICES = SERVICES.map(s => (s.id === id ? service : s));
  return service;
}

export async function removeService(id) {
  await api.del(`/services/${id}`);
  SERVICES = SERVICES.filter(s => s.id !== id);
}

// El resumen de pagos (bruto, comisión, neto) ahora lo calcula el backend
// sobre movimientos reales — ya no es una simulación con datos inventados.
export async function fetchPaymentsSummary(clientsById) {
  const { rows, totalBruto, totalComision, aprobados } = await api.get("/payments/summary");
  const enriched = rows.map(r => ({
    day: new Date(r.created_at.replace(" ", "T") + "Z").getDate(),
    name: (r.client_id && clientsById[r.client_id]) || "Cliente",
    concept: (SERVICES.find(s => s.id === r.service_id) || {}).name || "Servicio",
    monto: r.amount_cents, comision: r.commission_cents, approved: r.status === "approved",
  }));
  return { rows: enriched, totalBruto, totalComision, aprobados, neto: totalBruto - totalComision };
}
