// /services/natalChartService.js
// El CÁLCULO sigue exactamente igual (astrology-engine, sin tocar). Lo que
// cambia es la persistencia: antes CHARTS vivía solo en memoria, ahora cada
// carta calculada se manda al backend para guardarse, y las cartas viejas
// se traen de ahí (no se recalculan — se lee lo que ya se calculó una vez).

import { generateChart as calculateChart } from "../astrology-engine/index.js";
import { api } from "./apiClient.js";

let CHARTS = [];
let currentChartId = null;

// Convierte el registro que devuelve el backend (con los campos *_json como
// strings) a la misma forma de objeto que ya usan todos los componentes.
function hydrateChart(row) {
  const createdAt = new Date(row.created_at.replace(" ", "T") + "Z");
  const weeksAgo = Math.floor((Date.now() - createdAt.getTime()) / (7 * 86400000));
  return {
    id: row.id,
    clientId: row.client_id,
    type: row.type,
    positions: JSON.parse(row.positions_json),
    houseCusps: JSON.parse(row.house_cusps_json),
    aspects: JSON.parse(row.aspects_json),
    ascLon: row.asc_lon,
    mcLon: row.mc_lon,
    housesReliable: !!row.houses_reliable,
    engine: row.engine,
    interpGenerated: !!row.interp_generated,
    interpText: row.interp_text,
    createdAt: row.created_at,
    weeksAgo: Math.max(0, Math.min(5, weeksAgo)),
  };
}

export async function fetchCharts() {
  const rows = await api.get("/charts");
  CHARTS = rows.map(hydrateChart);
  return CHARTS;
}

export function getCharts() {
  return CHARTS;
}

export function findChart(id) {
  return CHARTS.find(c => c.id === id);
}

export function getChartsByClient(clientId) {
  return CHARTS.filter(c => c.clientId === clientId);
}

export function getCurrentChart() {
  return findChart(currentChartId);
}

export function setCurrentChartId(id) {
  currentChartId = id;
}

// Calcula la carta localmente (astrology-engine, ya validado) y la persiste
// en el backend. El objeto que devuelve mantiene la misma forma de siempre
// — solo el id final es el que asignó el servidor.
export async function createChartForClient(client) {
  const localChart = calculateChart(client, "tmp");
  const saved = await api.post("/charts", {
    clientId: client.id,
    positions: localChart.positions,
    houseCusps: localChart.houseCusps,
    aspects: localChart.aspects,
    ascLon: localChart.ascLon,
    mcLon: localChart.mcLon,
    housesReliable: localChart.housesReliable,
    engine: localChart.engine,
    type: localChart.type,
  });
  localChart.id = saved.id;
  localChart.createdAt = saved.created_at;
  localChart.weeksAgo = 0; // recién creada — esta semana
  CHARTS = [localChart, ...CHARTS];
  return localChart;
}

export async function saveInterpretation(chartId, text) {
  await api.put(`/charts/${chartId}/interpretation`, { text });
  const chart = findChart(chartId);
  if (chart) { chart.interpGenerated = true; chart.interpText = text; }
}

export function bodyLabel(name) {
  const chart = getCurrentChart();
  const d = chart && chart.positions[name];
  return (d && d.fullName) || (name[0].toUpperCase() + name.slice(1));
}
