-- =====================================================================
-- PLATAFORMA INTEGRAL PARA ASTRÓLOGOS — ESQUEMA DE BASE DE DATOS
-- PostgreSQL 15+
-- Convención: cada astrólogo es un "tenant". Todo dato de negocio
-- cuelga de tenant_id para poder aislar / particionar en el futuro.
-- =====================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ---------------------------------------------------------------------
-- 1. TENANTS (cuenta de astrólogo) Y USUARIOS
-- ---------------------------------------------------------------------

CREATE TABLE tenants (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    slug                TEXT UNIQUE NOT NULL,          -- usado en subdominio: mariana.plataforma.com
    display_name        TEXT NOT NULL,
    custom_domain       TEXT UNIQUE,                   -- opcional, dominio propio
    plan                TEXT NOT NULL DEFAULT 'free',   -- free | profesional | estudio
    branding            JSONB NOT NULL DEFAULT '{}',    -- colores, logo_url, fuente, bio
    default_house_system TEXT NOT NULL DEFAULT 'placidus',
    default_zodiac      TEXT NOT NULL DEFAULT 'tropical', -- tropical | sideral
    timezone            TEXT NOT NULL DEFAULT 'America/Argentina/Buenos_Aires',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE users (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID REFERENCES tenants(id) ON DELETE CASCADE, -- NULL si el user es un consultante multi-tenant
    email               TEXT UNIQUE NOT NULL,
    password_hash       TEXT,                          -- NULL si usa solo OAuth
    role                TEXT NOT NULL,                  -- owner | assistant | client
    full_name           TEXT NOT NULL,
    avatar_url          TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_users_tenant ON users(tenant_id);

-- ---------------------------------------------------------------------
-- 2. CLIENTES (consultantes) — CRM
-- ---------------------------------------------------------------------

CREATE TABLE clients (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    user_id             UUID REFERENCES users(id),      -- NULL si el astrólogo lo cargó sin invitar cuenta
    full_name           TEXT NOT NULL,
    email               TEXT,
    phone               TEXT,
    birth_date          DATE,
    birth_time          TIME,                            -- puede ser NULL (hora desconocida)
    birth_time_unknown  BOOLEAN NOT NULL DEFAULT false,
    birth_place_name    TEXT,
    birth_lat           NUMERIC(9,6),
    birth_lng           NUMERIC(9,6),
    birth_tz_offset_min INTEGER,                          -- offset histórico calculado, en minutos
    private_notes       TEXT,                             -- notas del astrólogo, NO visibles al cliente
    tags                TEXT[] DEFAULT '{}',
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_clients_tenant ON clients(tenant_id);

-- ---------------------------------------------------------------------
-- 3. CARTAS ASTRALES
-- Guardamos el resultado calculado (determinístico) como JSONB para no
-- recalcular en cada lectura. El motor de efemérides es la única fuente
-- de verdad al momento de generar; luego es snapshot inmutable.
-- ---------------------------------------------------------------------

CREATE TABLE charts (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    client_id           UUID REFERENCES clients(id) ON DELETE CASCADE,
    chart_type          TEXT NOT NULL,                  -- natal | transit | synastry | solar_return | progression | horary
    house_system        TEXT NOT NULL,
    zodiac_type         TEXT NOT NULL,
    input_datetime_utc  TIMESTAMPTZ NOT NULL,
    input_lat           NUMERIC(9,6) NOT NULL,
    input_lng           NUMERIC(9,6) NOT NULL,
    -- snapshot calculado por el motor de efemérides:
    positions           JSONB NOT NULL,   -- { "sun": {"lon": 123.45, "sign": "leo", "house": 5, "retrograde": false}, ... }
    houses              JSONB NOT NULL,   -- cúspides de las 12 casas
    aspects             JSONB NOT NULL,   -- [{ "a":"sun","b":"moon","type":"trine","orb":1.2 }, ...]
    related_chart_id    UUID REFERENCES charts(id), -- para sinastría/tránsitos: carta base contra la que se compara
    engine_version      TEXT NOT NULL,    -- versión del microservicio de cálculo, para auditar precisión
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_charts_tenant_client ON charts(tenant_id, client_id);

-- ---------------------------------------------------------------------
-- 4. INTERPRETACIÓN CON IA
-- Separamos "plantilla" (configuración reusable de estilo/escuela) de
-- "draft" (resultado generado + editado para una carta puntual).
-- ---------------------------------------------------------------------

CREATE TABLE interpretation_templates (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    name                TEXT NOT NULL,                  -- ej. "Enfoque evolutivo — Mariana"
    school               TEXT NOT NULL,                  -- psicologica | evolutiva | vedica | karmica | tradicional
    tone_instructions   TEXT NOT NULL,                   -- voz del astrólogo, en sus palabras
    block_structure      JSONB NOT NULL,                  -- qué bloques incluir y en qué orden
    is_default           BOOLEAN NOT NULL DEFAULT false,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE interpretation_drafts (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    chart_id            UUID NOT NULL REFERENCES charts(id) ON DELETE CASCADE,
    template_id         UUID REFERENCES interpretation_templates(id),
    ai_raw_output       JSONB NOT NULL,     -- respuesta original del modelo, por bloque
    edited_content       JSONB NOT NULL,     -- versión final editada por el astrólogo, por bloque
    status                TEXT NOT NULL DEFAULT 'draft', -- draft | approved | sent
    exported_pdf_url     TEXT,
    created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at            TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------
-- 5. SERVICIOS, AGENDA Y TURNOS
-- ---------------------------------------------------------------------

CREATE TABLE services (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    name                TEXT NOT NULL,                  -- "Informe de carta natal", "Sesión de seguimiento 45min"
    description         TEXT,
    modality            TEXT NOT NULL,                   -- async_report | video_call | in_person
    duration_minutes    INTEGER,                          -- NULL si es async
    price_cents         INTEGER NOT NULL,
    currency            TEXT NOT NULL DEFAULT 'ARS',
    is_active            BOOLEAN NOT NULL DEFAULT true,
    created_at            TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE availability_rules (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    weekday             SMALLINT NOT NULL,               -- 0=domingo ... 6=sábado
    start_time          TIME NOT NULL,
    end_time            TIME NOT NULL,
    buffer_minutes      INTEGER NOT NULL DEFAULT 10
);

CREATE TABLE appointments (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    client_id           UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    service_id          UUID NOT NULL REFERENCES services(id),
    chart_id            UUID REFERENCES charts(id),
    starts_at            TIMESTAMPTZ NOT NULL,
    ends_at               TIMESTAMPTZ NOT NULL,
    status                TEXT NOT NULL DEFAULT 'scheduled', -- scheduled | completed | cancelled | no_show
    meeting_url           TEXT,
    created_at            TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_appointments_tenant_time ON appointments(tenant_id, starts_at);

-- ---------------------------------------------------------------------
-- 6. PAGOS Y SUSCRIPCIONES
-- Dos flujos de facturación distintos:
--  a) subscriptions: lo que el astrólogo paga a la plataforma
--  b) payments: lo que el cliente final paga al astrólogo por un servicio
-- ---------------------------------------------------------------------

CREATE TABLE subscriptions (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    plan                TEXT NOT NULL,
    status                TEXT NOT NULL,                  -- active | past_due | cancelled
    provider              TEXT NOT NULL,                   -- mercadopago | stripe
    provider_subscription_id TEXT,
    current_period_end   TIMESTAMPTZ,
    created_at            TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE payments (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    appointment_id       UUID REFERENCES appointments(id),
    client_id             UUID NOT NULL REFERENCES clients(id),
    amount_cents           INTEGER NOT NULL,
    currency               TEXT NOT NULL DEFAULT 'ARS',
    provider                TEXT NOT NULL,                  -- mercadopago | stripe
    provider_payment_id     TEXT,
    platform_fee_cents      INTEGER NOT NULL DEFAULT 0,     -- comisión de la plataforma
    status                    TEXT NOT NULL,                  -- pending | approved | refunded | failed
    created_at                TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------
-- 7. NOTIFICACIONES
-- ---------------------------------------------------------------------

CREATE TABLE notifications (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id           UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    recipient_type      TEXT NOT NULL,                   -- astrologer | client
    recipient_id         UUID NOT NULL,
    channel               TEXT NOT NULL,                   -- email | whatsapp | in_app
    event                  TEXT NOT NULL,                   -- appointment_reminder, transit_alert, payment_received...
    payload                JSONB NOT NULL DEFAULT '{}',
    sent_at                TIMESTAMPTZ,
    created_at             TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =====================================================================
-- NOTAS DE DISEÑO
-- =====================================================================
-- 1. positions/houses/aspects como JSONB: evita crear ~15 tablas para
--    algo que se lee siempre como bloque completo y nunca se filtra
--    por planeta individual a nivel SQL. Si en el futuro se necesita
--    hacer queries como "todos los clientes con Saturno en Casa 10",
--    conviene indexar con GIN: CREATE INDEX ON charts USING GIN (positions).
--
-- 2. interpretation_templates vs interpretation_drafts separa la
--    "configuración reusable" (cómo quiere escribir este astrólogo)
--    del "resultado puntual" (lo que se generó y editó para esta carta).
--
-- 3. tenant_id repetido en casi todas las tablas es intencional:
--    simplifica muchísimo el aislamiento multi-tenant a nivel de
--    Row Level Security de Postgres (se puede activar RLS por tenant_id
--    sin joins complejos).
-- =====================================================================
