# Editor de interpretación por bloques — comportamiento

## Estados de un bloque

Cada bloque (`interpretation_drafts`, un campo del JSON por sección) pasa por estados independientes entre sí — un astrólogo puede tener "Síntesis" ya aprobado mientras "Aspectos relevantes" todavía está generándose:

1. **Generando** — spinner discreto, texto placeholder tenue. No bloquea los demás bloques (se piden en paralelo, no en cadena).
2. **Borrador IA** — texto recién generado, badge dorado "Generado con IA", sin editar todavía. Es el estado en que vive `ai_raw_output`.
3. **Editado** — el astrólogo tocó el texto. Badge cambia a "Editado" (gris). A partir de acá `edited_content` diverge de `ai_raw_output`, y el diff se guarda para el loop de mejora de plantillas.
4. **Aprobado** — el astrólogo marca el bloque como listo (check). Solo bloques aprobados entran al PDF final o al envío al cliente.
5. **Bloqueado por escuela** — si el bloque requiere una condición no cumplida (ej. interpretación védica sobre una carta calculada en trópico), se muestra deshabilitado con explicación en vez de texto generado.

## Acciones disponibles por bloque

- **Regenerar** — vuelve a llamar a la IA con el mismo payload. Si el bloque ya estaba editado, pregunta antes de descartar la edición ("Tenés cambios sin guardar en este bloque — ¿regenerar de todas formas?").
- **Editar** — convierte el `<p>` de solo lectura en `<textarea>`, foco automático, autosave al perder foco (no hace falta botón "Guardar" explícito, reduce fricción).
- **Revertir a versión IA** — descarta la edición y vuelve a `ai_raw_output`, disponible solo mientras no se aprobó el bloque.
- **Aprobar** — marca el bloque como listo para exportar. Un contador en la parte superior del editor muestra "3/4 bloques aprobados" para que el astrólogo sepa si falta revisar algo antes de enviar.
- **Reordenar** — drag and drop entre bloques (afecta `block_structure` de la plantilla si el astrólogo decide guardar el nuevo orden como default).
- **Marcar frase como "no uses esto"** — selección de texto dentro de un bloque, click derecho → "Nunca sugerir esto de nuevo". Se guarda como regla negativa asociada a la plantilla del astrólogo (lista de frases/patrones a evitar en futuras generaciones).

## Reglas de envío

- El botón "Enviar a cliente" / "Exportar PDF" queda deshabilitado si hay bloques en estado "Generando" o si algún bloque obligatorio de la plantilla no fue aprobado.
- Si el astrólogo intenta salir de la vista con bloques editados sin aprobar, se le avisa (no se pierde nada — todo autosave — pero se le recuerda que falta aprobar antes de que el cliente lo vea).

## Loop de aprendizaje (resumen operativo)

Cada edición se registra como:
```json
{ "chart_id": "...", "block": "aspectos_relevantes", "ai_version": "...", "edited_version": "...", "template_id": "..." }
```
Una vez por semana, un job agrega estas diferencias por astrólogo y arma un resumen tipo "En el 60% de tus interpretaciones de 'Aspectos relevantes' acortaste el párrafo final — ¿querés que ajustemos la plantilla para que sea más breve por default?" — el astrólogo confirma o descarta, nunca se aplica solo.
