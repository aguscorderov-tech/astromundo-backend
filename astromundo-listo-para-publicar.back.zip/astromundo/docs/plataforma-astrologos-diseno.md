# Plataforma Integral para Astrólogos — Documento de Diseño

## 1. Visión y propuesta de valor

Una plataforma SaaS donde un astrólogo profesional (o que quiere profesionalizarse) tiene en un solo lugar:

- **Motor de cálculo astral** (cartas natales, tránsitos, progresiones, sinastría, revoluciones solares)
- **Asistente de interpretación con IA** que ayuda a redactar informes, dar contexto a los aspectos y aspectos personalizando el tono según el astrólogo
- **CRM de práctica**: fichas de clientes, historial de consultas, notas
- **Agenda y turnos**: reservas online, recordatorios, pagos
- **Tienda de servicios**: venta de lecturas, informes en PDF, paquetes de sesiones, suscripciones
- **Página pública** tipo "mini sitio" para cada astrólogo, con su marca

La idea central: el astrólogo no compite armando su propia herramienta de cálculo ni su propio sistema de cobros — se enfoca en atender clientes, y la plataforma le da el "back office" completo.

### Dos mercados a servir
1. **El astrólogo** (usuario profesional, paga suscripción) — es el cliente que genera ingresos recurrentes.
2. **El consultante/cliente final** (usa la plataforma para agendar, pagar, recibir su informe) — no paga suscripción, pero es quien valida que la experiencia funcione.

---

## 2. Personas

**Astrólogo profesional (Mariana, 38 años)**
Ya tiene clientes por Instagram y WhatsApp. Usa Excel para turnos y cobra por transferencia. Quiere verse más profesional, dejar de perder tiempo armando cartas a mano y ahorrar horas de redacción de informes.

**Astrólogo en formación (Tomás, 26 años)**
Terminó un curso de astrología, quiere empezar a cobrar pero no tiene clientela ni sabe fijar precios. Necesita herramientas que lo ayuden a verse creíble desde el día uno.

**Consultante (Lucía, 31 años)**
Quiere una lectura de su carta natal o una consulta de tránsitos. Busca por Instagram, reserva, paga y espera un informe o una videollamada.

---

## 3. Flujos de usuario clave

### 3.1 Onboarding del astrólogo
1. Se registra (email/Google) → elige plan
2. Completa perfil: nombre profesional, bio, foto, especialidades (natal, sinastría, horaria, védica, etc.), idioma, tono de escritura preferido
3. Configura su "mini sitio" público (subdominio tipo `mariana.tuplataforma.com` o dominio propio)
4. Configura métodos de cobro (Mercado Pago / Stripe) y disponibilidad de agenda
5. Define sus servicios: tipo, duración, precio, modalidad (async por informe / videollamada)
6. Tutorial guiado: genera su primera carta de prueba y ve cómo la IA arma un borrador de interpretación

### 3.2 Cálculo e interpretación de una carta
1. El astrólogo (o el cliente, según el flujo) ingresa datos de nacimiento: fecha, hora, lugar (autocompletado con geocoding + zona horaria histórica)
2. El motor de efemérides calcula posiciones planetarias, casas (con sistema configurable: Placidus, Koch, Whole Sign, etc.), aspectos
3. Se genera la rueda natal (SVG interactivo)
4. El astrólogo pide a la IA un borrador de interpretación:
   - Elige enfoque (psicológica, evolutiva, védica, kármica, etc.)
   - La IA arma un texto estructurado por bloques (Sol/Luna/Ascendente, planetas por casa, aspectos relevantes, síntesis)
   - El astrólogo edita, agrega su voz, guarda como plantilla reusable
5. Exporta como PDF con su marca, o lo dejar programado para enviar automáticamente al cliente

### 3.3 Flujo del cliente final (consultante)
1. Entra al mini sitio del astrólogo → ve servicios y precios
2. Elige un servicio (ej. "Informe de carta natal" o "Sesión de 45 min")
3. Completa datos de nacimiento (si aplica) y elige horario disponible en el calendario
4. Paga online
5. Recibe confirmación + recordatorios automáticos (email/WhatsApp)
6. Recibe su informe en PDF o accede a la videollamada agendada
7. Puede dejar reseña y volver a agendar

### 3.4 Gestión de la práctica (día a día del astrólogo)
1. Dashboard: próximos turnos, clientes nuevos, pagos pendientes, ingresos del mes
2. Ficha de cliente: historial de cartas calculadas, consultas previas, notas privadas, próximos tránsitos relevantes de esa persona
3. Alertas automáticas: "Fulano tiene Saturno en tránsito por su Sol este mes — ¿le ofrecés una consulta de seguimiento?"
4. Reportes de ventas y ocupación de agenda

---

## 4. Diseño UX/UI — lineamientos

- **Identidad visual dual**: el back office (herramienta de trabajo) debe verse profesional y sobrio — no esotérico, para transmitir seriedad de negocio. El mini sitio público de cada astrólogo, en cambio, debe ser personalizable (paletas oscuras/celestiales, tipografías con carácter) para que cada uno exprese su marca.
- **Rueda natal como centro visual**: interactiva, con hover en cada planeta/aspecto que muestra detalle. Debe funcionar bien en mobile (los clientes finales entran mayormente desde el celular).
- **Editor de interpretaciones tipo "documento colaborativo"**: texto generado por IA a la izquierda, panel de edición a la derecha, con bloques reordenables (por planeta, por casa, por tema).
- **Agenda tipo Calendly simplificado**: vista de disponibilidad, bloqueo automático de franjas ya reservadas, buffer entre turnos.
- **Mobile-first para el cliente final**, desktop-first para el panel del astrólogo (trabajo más denso en datos).

---

## 5. Arquitectura técnica

### 5.1 Visión general (alto nivel)

```
┌─────────────────┐     ┌──────────────────┐     ┌─────────────────┐
│  Frontend Web    │     │   API Backend     │     │  Motor Astral    │
│  (Next.js)       │────▶│  (Node/NestJS o   │────▶│  (Swiss Ephemeris│
│  - App astrólogo │     │   Django)         │     │   + microservicio│
│  - Mini sitios    │     │  - Auth           │     │   de cálculo)    │
│  - App cliente    │     │  - CRM            │     └─────────────────┘
└─────────────────┘     │  - Agenda/pagos   │
                          │  - Orquestación IA│     ┌─────────────────┐
                          └────────┬─────────┘────▶│  Claude API      │
                                   │                │  (interpretación,│
                          ┌────────▼─────────┐     │   redacción)     │
                          │  Base de datos    │     └─────────────────┘
                          │  (Postgres)       │
                          │  + almacenamiento │     ┌─────────────────┐
                          │  de archivos (S3)  │────▶│  Pasarela de pago│
                          └───────────────────┘     │  (Mercado Pago/  │
                                                      │   Stripe)        │
                                                      └─────────────────┘
```

### 5.2 Componentes principales

**Frontend**
- Next.js (React) — permite SSR para los mini sitios públicos (SEO importa mucho acá: cada astrólogo quiere aparecer en Google)
- Multi-tenant por subdominio o dominio custom
- Componentes separados: panel astrólogo (dashboard denso) vs. mini sitio público (liviano, orientado a conversión)

**Backend / API**
- Node.js con NestJS (o Django si preferís Python, que además facilita integrar librerías astronómicas)
- Autenticación con roles: astrólogo (admin de su cuenta), asistente (si tiene equipo), cliente final (cuenta liviana solo para ver sus turnos/informes)
- Módulos: Usuarios, Clientes/CRM, Cartas, Agenda, Pagos, Servicios, Notificaciones

**Motor de cálculo astrológico**
- Basado en **Swiss Ephemeris** (librería estándar, precisa, usada por la mayoría de software astrológico serio) — hay wrappers en Python (`pyswisseph`) y Node
- Servicio separado (microservicio) que recibe fecha/hora/lugar y devuelve posiciones planetarias, casas, aspectos en JSON
- Geocoding + zona horaria histórica: necesario un servicio tipo GeoNames o Google Geocoding + una librería de zonas horarias históricas (importante para nacimientos antes de husos horarios modernos)

**Capa de IA (interpretación)**
- Integración con la API de Claude
- El prompt no genera "la carta" (eso lo hace el motor determinístico) — genera **interpretación de texto** a partir de los datos ya calculados (posiciones, casas, aspectos) más el enfoque elegido por el astrólogo
- Conviene versionar "perfiles de interpretación" (plantillas de prompt) por escuela astrológica y por astrólogo, para que cada uno pueda entrenar su propio "tono"
- Guardar feedback del astrólogo (qué edita, qué descarta) para ir afinando las plantillas de prompt con el tiempo

**Base de datos**
- PostgreSQL como base relacional principal (usuarios, clientes, turnos, pagos, servicios)
- Las cartas calculadas se pueden guardar como JSON (columna JSONB) asociadas al cliente, para no recalcular cada vez
- Almacenamiento de archivos (PDFs generados, imágenes de marca) en S3 o equivalente

**Pagos**
- Mercado Pago como prioridad para Argentina/LatAm, Stripe para expansión internacional
- Suscripciones (planes del astrólogo) + cobros por transacción (lo que paga el cliente final) — dos flujos de facturación distintos

**Notificaciones**
- Email transaccional (Resend/SendGrid) + WhatsApp Business API para recordatorios de turnos (muy usado en el público hispanohablante)

**Generación de PDF**
- Servicio de renderizado (ej. Puppeteer o una librería de PDF) que toma la interpretación final + diseño de marca del astrólogo y arma el informe descargable

### 5.3 Consideraciones de escalabilidad y multi-tenant
- Cada astrólogo es un "tenant" — aislar datos por `tenant_id` en cada tabla
- Los mini sitios públicos deben cachear agresivamente (son de bajo cambio, alto tráfico potencial si el astrólogo tiene audiencia)
- El cálculo astral es CPU-intensivo pero rápido — se puede correr sin cola, pero conviene tener un límite de rate por si se hace scraping masivo de cartas

---

## 6. Modelo de monetización sugerido

- **Plan gratuito**: hasta X cartas/mes, sin mini sitio propio (o con marca de la plataforma), sin pagos online
- **Plan profesional** (mensual): mini sitio propio, cartas ilimitadas, IA de interpretación, agenda y pagos habilitados, comisión baja por transacción
- **Plan estudio** (para astrólogos con equipo o mucha clientela): múltiples usuarios, reportes avanzados, marca 100% blanca

---

## 7. Roadmap sugerido (fases)

1. **MVP**: cálculo de carta natal + rueda visual + interpretación IA básica + export PDF (sin agenda ni pagos todavía) — validar que el cálculo y la interpretación generan valor real
2. **Fase 2**: mini sitio público + agenda + pagos → ya se puede vender el servicio de punta a punta
3. **Fase 3**: CRM avanzado (alertas de tránsitos, historial), tránsitos y sinastría, plantillas de interpretación entrenables
4. **Fase 4**: app de cliente final (ver su historial, comprar directamente), marketplace de astrólogos dentro de la plataforma

---

## 8. Riesgos y puntos a validar primero

- **Precisión astronómica**: no negociable — un error en casas o zona horaria histórica arruina la confianza del astrólogo en la herramienta. Conviene validar el motor de cálculo contra software de referencia (ej. Astro.com) antes de lanzar.
- **Calidad de la interpretación IA**: el astrólogo necesita sentir que puede editar y que el texto "no suena genérico". Vale la pena invertir tiempo en las plantillas de prompt por escuela astrológica.
- **Fricción de pago para el cliente final**: si el checkout es largo, se pierde la venta. Priorizar un flujo de 2-3 pasos máximo.
