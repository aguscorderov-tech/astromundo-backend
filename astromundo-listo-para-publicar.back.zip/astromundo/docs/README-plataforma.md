# Plataforma Integral para Astrólogos — Documentación completa

Este es el índice de todo lo desarrollado. Cada archivo puede leerse de forma independiente, pero acá va el orden recomendado si alguien nuevo se suma al proyecto.

## 1. Producto y diseño
- **`plataforma-astrologos-diseno.md`** — visión, propuesta de valor, personas, flujos de usuario completos (onboarding, cálculo/interpretación, cliente final, gestión de práctica), lineamientos UX/UI, arquitectura general, modelo de monetización y roadmap por fases.

## 2. Mockups navegables (abrir directo en el navegador)
- **`mockup-dashboard-astrologo.html`** — panel diario del astrólogo: agenda, clientes, ingresos, alertas de tránsitos.
- **`mockup-vista-carta-natal.html`** — la pantalla principal de trabajo: rueda natal generada por código + editor de interpretación por bloques con IA.
- **`mockup-mini-sitio-publico.html`** — sitio público del astrólogo donde el consultante ve servicios y reserva.
- **`mockup-app-cliente.html`** — portal del consultante: turnos, informes descargables, historial, reserva rápida.

## 3. Ingeniería
- **`schema.sql`** — esquema completo de base de datos PostgreSQL (multi-tenant): tenants, clientes, cartas, plantillas de interpretación, servicios, agenda, pagos, notificaciones.
- **`microservicio-calculo-astral.md`** — diseño del motor de cálculo astrológico: Swiss Ephemeris, resolución de zona horaria histórica, contrato de API (`/calculate`, `/transits`, `/synastry`), esqueleto de código y estrategia de validación de precisión.
- **`sistema-prompts-ia.md`** — arquitectura de la interpretación con IA: separación cálculo/interpretación, system prompt, plantillas por escuela astrológica, salvaguardas contra lenguaje predictivo.
- **`editor-interpretacion-comportamiento.md`** — estados y acciones del editor de bloques (generar, editar, aprobar, regenerar, revertir) y el loop de mejora continua de las plantillas.

## 4. Negocio
- **`plan-negocio-pricing.md`** — planes y precios (Gratis / Profesional / Estudio), unit economics con números concretos, costos variables a monitorear, canales de adquisición y roadmap de negocio a 6 meses.

---

## Resumen de decisiones de arquitectura clave

1. **Cálculo y interpretación están separados de raíz.** El microservicio de Swiss Ephemeris es la única fuente de verdad para posiciones/casas/aspectos; la IA solo redacta texto sobre esos datos ya correctos. Esto evita que un error de IA se confunda con un error astronómico.

2. **Multi-tenant por diseño desde el modelo de datos**, no agregado después — todas las tablas de negocio cuelgan de `tenant_id`, lo que permite aislar datos por astrólogo con Row Level Security sin reestructurar nada más adelante.

3. **Todo lo generado por IA es editable y versionado por bloque**, nunca un texto monolítico — esto es lo que hace que el astrólogo confíe en la herramienta (puede corregir sin pelear con un párrafo entero) y es también lo que alimenta el loop de mejora de las plantillas de interpretación.

4. **El modelo de negocio combina suscripción fija + comisión variable**, así los incentivos de la plataforma y del astrólogo están alineados: la plataforma gana más cuando el astrólogo vende más, no solo por existir.

## Qué falta para llegar a un MVP construible

- Elegir proveedor de geocoding + confirmar cobertura de zonas horarias históricas para los países objetivo
- Definir el set de ~20 cartas de referencia para validar precisión antes de lanzar
- Prototipar el prompt de interpretación con casos reales y afinar las plantillas con 2-3 astrólogos piloto
- Definir el contrato exacto de la pasarela de pago (Mercado Pago primero) y el flujo de comisión/liquidación al astrólogo
