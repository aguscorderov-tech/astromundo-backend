# Sistema de interpretación con IA — diseño de prompts

## Principio de diseño

La IA **nunca calcula posiciones astronómicas** — eso ya viene resuelto y verificado por el motor de efemérides (Swiss Ephemeris) en `charts.positions / houses / aspects`. El único trabajo de la IA es **redactar interpretación en lenguaje natural** a partir de datos ya correctos. Esto separa el riesgo de "alucinación" (grave si inventa una posición planetaria) del riesgo de "texto genérico" (molesto pero corregible con edición).

Consecuencia práctica: el prompt siempre recibe el JSON de la carta ya calculada como contexto — nunca le pedimos al modelo que "calcule" nada, solo que interprete.

## Arquitectura del flujo

```
1. Usuario pide interpretación de charts.id = X
2. Backend arma el payload:
   - datos de la carta (positions, houses, aspects)
   - plantilla elegida (interpretation_templates: escuela, tono, estructura de bloques)
   - datos mínimos del consultante (nombre, para personalizar el saludo — nunca datos sensibles de más)
3. Se llama a Claude con system prompt fijo + este payload como contexto
4. Se pide salida estructurada en JSON (un bloque por sección)
5. El backend guarda la salida cruda en interpretation_drafts.ai_raw_output
6. El astrólogo edita en el editor de bloques → se guarda en edited_content
7. Ese edited_content (no el raw) es lo que se exporta a PDF
```

## System prompt base (fijo, no cambia por astrólogo)

```
Sos un asistente de redacción para astrólogos profesionales. Tu tarea es
transformar datos astrológicos ya calculados en un texto de interpretación
claro, cálido y profesional — nunca calculás ni corregís posiciones
planetarias, casas o aspectos: los tomás como verdad dada.

Reglas:
- No inventes datos que no estén en el JSON de entrada.
- No uses lenguaje absoluto o determinista ("vas a", "vas a sufrir",
  "esto va a pasar seguro"). Usá lenguaje de tendencia y posibilidad.
- No des diagnósticos médicos ni psicológicos.
- Adaptate estrictamente al tono y escuela indicados en la plantilla.
- Devolvé la respuesta como JSON válido, un campo por bloque solicitado,
  sin texto fuera del JSON.
```

## Payload de usuario (varía por carta)

```json
{
  "consultante": { "nombre": "Lucía" },
  "escuela": "evolutiva",
  "tono": "cercano, sin tecnicismos innecesarios, tuteo",
  "bloques_solicitados": ["sol_luna_ascendente", "planetas_por_casa", "aspectos_relevantes", "sintesis"],
  "carta": {
    "positions": { "...": "..." },
    "houses": { "...": "..." },
    "aspects": [ "...": "..." ]
  }
}
```

## Formato de salida esperado

```json
{
  "sol_luna_ascendente": "texto...",
  "planetas_por_casa": "texto...",
  "aspectos_relevantes": "texto...",
  "sintesis": "texto..."
}
```

Cada bloque se guarda por separado en `interpretation_drafts.ai_raw_output` — esto es lo que permite el editor tipo "documento por bloques reordenables" del frontend: cada bloque es una unidad editable independiente, no un texto corrido.

## Plantillas por escuela (interpretation_templates)

Cada astrólogo elige o crea sus propias plantillas. Ejemplos de partida que la plataforma podría ofrecer preconfiguradas:

**Psicológica**
- Foco: patrones internos, mecanismos de defensa, procesos de individuación
- Vocabulario permitido: "tendencia a", "patrón interno", "necesidad no resuelta"
- Vocabulario evitado: términos de destino o predicción fija

**Evolutiva**
- Foco: propósito del alma, lecciones kármicas (a través de Nodos Lunares y regente de casa 12)
- Vocabulario permitido: "camino de aprendizaje", "lo que venís a integrar"

**Védica**
- Requiere que la carta se haya calculado con `zodiac_type = sideral` y sistema de casas apropiado — la plantilla debe validar esto antes de generar, para no mezclar un texto védico sobre una carta calculada en trópico

**Tradicional/clásica**
- Foco: dignidades planetarias, casas angulares/sucedentes/cadentes, sin lenguaje psicológico moderno

## Loop de mejora continua

- Cada vez que el astrólogo edita un bloque generado, se guarda el diff entre `ai_raw_output` y `edited_content`
- Periódicamente se puede analizar qué tipo de ediciones son recurrentes por astrólogo (¿siempre acorta? ¿siempre saca la misma frase hecha? ¿agrega siempre una advertencia al final?) para sugerir ajustes a `tone_instructions` de su plantilla
- Este loop es semi-automático al inicio (reporte para que el astrólogo revise sugerencias), no debería reescribir la plantilla sin que el astrólogo lo confirme

## Salvaguardas específicas del dominio

- **No determinismo predictivo**: bloquear frases tipo "vas a divorciarte", "vas a tener un accidente" — filtro de salida adicional (regex + revisión) antes de mostrar el borrador, además de la instrucción en el prompt
- **Temas sensibles**: si la carta se usa en contexto de consulta sobre salud, duelo o crisis vital, la plantilla debe agregar una instrucción explícita de tono cuidadoso y evitar cualquier afirmación categórica
- **Idioma y localismos**: el `tono` de cada plantilla debería fijar variante de español (rioplatense, neutro, etc.) para que no se note "traducido"
