# Microservicio de cálculo astral — diseño técnico

## Por qué es un microservicio aparte

El cálculo astronómico es **CPU-bound**, determinístico, y no tiene nada que ver con el resto del dominio (CRM, pagos, agenda). Separarlo permite:
- Escalarlo independiente del resto de la API (picos de uso cuando muchos astrólogos generan cartas a la vez)
- Poder reescribirlo o cambiar de librería sin tocar el backend principal
- Testearlo de forma aislada contra referencias externas (Astro.com, Astrodienst) sin dependencias de negocio

Vive detrás de la API principal, nunca expuesto directo a internet.

## Stack elegido

**Python + FastAPI + `pyswisseph`**

Swiss Ephemeris es el estándar de facto en software astrológico serio (usado por Astro.com, Solar Fire, y la mayoría de apps profesionales) — precisión de segundos de arco, cubre un rango de miles de años, y `pyswisseph` es el binding más maduro. Se podría hacer en Node con `swisseph` (binding también existe) pero el ecosistema Python tiene más herramientas auxiliares (timezonefinder, astropy) que simplifican los pasos previos al cálculo.

## Los tres problemas reales de precisión (antes de tocar Swiss Ephemeris)

La mayoría de los bugs de un software astrológico no están en el cálculo planetario en sí — están en lo que pasa **antes**:

### 1. Resolver lat/lng a partir del nombre del lugar
- Geocoding (Google Geocoding API o Nominatim/OpenStreetMap) para convertir "Rosario, Argentina" → lat/lng
- Guardar siempre lat/lng numérico en la base, nunca solo el texto — el texto es para mostrar, las coordenadas son la fuente de verdad para el cálculo

### 2. Resolver la hora local a UTC — el paso donde más se rompen las cartas
- No alcanza con la zona horaria *actual* del lugar: hay que resolver la zona horaria **vigente en la fecha de nacimiento**, incluyendo horario de verano histórico (Argentina tuvo horario de verano de forma discontinua hasta 2009, por ejemplo)
- Librería: `timezonefinder` (lat/lng → nombre de zona horaria tipo `America/Argentina/Buenos_Aires`) + `pytz` o `zoneinfo` con datos históricos (la base de datos IANA tzdata ya incluye las reglas históricas de cada país)
- Guardar en `charts.input_datetime_utc` el resultado ya convertido — nunca recalcular la conversión después, es un snapshot

### 3. Hora de nacimiento desconocida
- Si `birth_time_unknown = true`: calcular igual con una hora convencional (usualmente 12:00 mediodía) pero **no calcular casas ni Ascendente** — solo posiciones planetarias por signo, y marcar claramente en la UI que las casas no son confiables
- Esto tiene que ser explícito en el JSON de salida (`"houses_reliable": false`) para que ni el frontend ni la IA de interpretación traten esa carta como si tuviera casas certeras

## Contrato de API

### `POST /internal/charts/calculate`

**Request**
```json
{
  "datetime_utc": "1994-08-14T15:32:00Z",
  "latitude": -32.9468,
  "longitude": -60.6393,
  "house_system": "placidus",
  "zodiac_type": "tropical",
  "houses_reliable": true
}
```

**Response**
```json
{
  "engine_version": "swisseph-2.10.03",
  "positions": {
    "sun":     { "lon": 141.87, "sign": "leo",    "sign_deg": 21.87, "house": 5, "retrograde": false, "speed": 0.96 },
    "moon":    { "lon": 20.14,  "sign": "aries",   "sign_deg": 20.14, "house": 1, "retrograde": false, "speed": 13.1 },
    "mercury": { "lon": 160.22, "sign": "virgo",   "sign_deg": 10.22, "house": 6, "retrograde": false, "speed": 1.4 },
    "venus":   { "lon": 175.05, "sign": "virgo",   "sign_deg": 25.05, "house": 6, "retrograde": false, "speed": 1.1 },
    "mars":    { "lon": 200.31, "sign": "libra",   "sign_deg": 20.31, "house": 7, "retrograde": false, "speed": 0.6 },
    "jupiter": { "lon": 95.44,  "sign": "cancer",  "sign_deg": 5.44,  "house": 4, "retrograde": false, "speed": 0.2 },
    "saturn":  { "lon": 310.12, "sign": "aquarius","sign_deg": 10.12, "house": 11,"retrograde": false, "speed": 0.08 },
    "uranus":  { "lon": 45.67,  "sign": "taurus",  "sign_deg": 15.67, "house": 2, "retrograde": false, "speed": 0.04 },
    "neptune": { "lon": 355.90, "sign": "pisces",  "sign_deg": 25.90, "house": 12,"retrograde": false, "speed": 0.02 },
    "pluto":   { "lon": 280.33, "sign": "capricorn","sign_deg": 10.33,"house": 10,"retrograde": false, "speed": 0.01 }
  },
  "houses": {
    "system": "placidus",
    "cusps": [10.0, 38.5, 65.2, 95.0, 120.1, 148.9, 190.0, 218.5, 245.2, 275.0, 300.1, 328.9],
    "ascendant": 10.0,
    "midheaven": 275.0
  },
  "aspects": [
    { "a": "sun", "b": "moon", "type": "square", "orb": 1.7, "applying": false },
    { "a": "venus", "b": "mars", "type": "sextile", "orb": 0.4, "applying": true },
    { "a": "sun", "b": "pluto", "type": "opposition", "orb": 2.5, "applying": true }
  ]
}
```

### `POST /internal/charts/transits`
Mismo contrato, pero recibe además `related_chart_id` (o directamente las posiciones natales) para devolver aspectos entre tránsito y carta natal — reutiliza el mismo motor de aspectos, cambia solo el segundo set de posiciones.

### `POST /internal/charts/synastry`
Recibe dos cartas ya calculadas, devuelve únicamente la matriz de aspectos cruzados entre ambas — no recalcula posiciones, es una función pura sobre datos ya existentes.

## Estructura de código (esqueleto)

```
calc-service/
├── main.py                  # FastAPI app, define los 3 endpoints
├── ephemeris/
│   ├── engine.py             # wrapper sobre pyswisseph, una función por tipo de cálculo
│   ├── houses.py             # cálculo de cúspides según sistema elegido
│   ├── aspects.py            # matriz de aspectos + orbes configurables
│   └── zodiac.py             # tropical vs sideral (ayanamsa), lon → signo
├── timezone_resolver.py       # lat/lng + fecha → UTC (timezonefinder + tzdata histórico)
└── tests/
    └── test_reference_charts.py  # cartas de referencia validadas contra Astro.com
```

**`ephemeris/engine.py` (esqueleto simplificado)**
```python
import swisseph as swe

PLANETS = {
    "sun": swe.SUN, "moon": swe.MOON, "mercury": swe.MERCURY,
    "venus": swe.VENUS, "mars": swe.MARS, "jupiter": swe.JUPITER,
    "saturn": swe.SATURN, "uranus": swe.URANUS,
    "neptune": swe.NEPTUNE, "pluto": swe.PLUTO,
}

def calculate_positions(julian_day: float, zodiac_type: str) -> dict:
    flags = swe.FLG_SWIEPH
    if zodiac_type == "sideral":
        swe.set_sid_mode(swe.SIDM_LAHIRI)  # ayanamsa configurable
        flags |= swe.FLG_SIDEREAL

    result = {}
    for name, body_id in PLANETS.items():
        lon, lat, dist, speed_lon, *_ = swe.calc_ut(julian_day, body_id, flags)[0]
        result[name] = {
            "lon": round(lon, 2),
            "sign": lon_to_sign(lon),
            "sign_deg": round(lon % 30, 2),
            "retrograde": speed_lon < 0,
            "speed": round(speed_lon, 3),
        }
    return result
```

**`ephemeris/aspects.py` (esqueleto)**
```python
ASPECTS = {
    "conjunction": (0, 8), "sextile": (60, 4), "square": (90, 6),
    "trine": (120, 6), "opposition": (180, 8),
}

def calculate_aspects(positions: dict) -> list:
    bodies = list(positions.items())
    found = []
    for i in range(len(bodies)):
        for j in range(i + 1, len(bodies)):
            name_a, data_a = bodies[i]
            name_b, data_b = bodies[j]
            diff = abs(data_a["lon"] - data_b["lon"]) % 360
            diff = min(diff, 360 - diff)
            for aspect_name, (angle, max_orb) in ASPECTS.items():
                orb = abs(diff - angle)
                if orb <= max_orb:
                    found.append({
                        "a": name_a, "b": name_b, "type": aspect_name,
                        "orb": round(orb, 2),
                    })
    return found
```

## Validación de precisión (antes de lanzar)

Suite de tests contra un set de ~20 cartas de referencia (personas con hora de nacimiento pública y verificada, o cartas de ejemplo de manuales de astrología reconocidos), comparando cada posición y cúspide contra lo que devuelve Astro.com para los mismos datos de entrada. Tolerancia: diferencias mayores a algunos segundos de arco indican un bug en el manejo de zona horaria o en la configuración de Swiss Ephemeris (efemérides vs. flags), no un problema de redondeo aceptable.

## Escalabilidad

- Cálculo de una carta: unos pocos milisegundos de CPU — no necesita cola de trabajos para uso normal
- Cachear resultados por `(datetime_utc, lat, lng, house_system, zodiac_type)` — mismos inputs siempre dan el mismo output, así que una carta ya calculada para esos parámetros nunca se recalcula
- Si en el futuro se agrega "efemérides en tiempo real" para tránsitos del día (muchos usuarios consultando "tránsitos de hoy" a la vez), ahí sí conviene precalcular 1 vez por día y servir desde caché en vez de recalcular por request
