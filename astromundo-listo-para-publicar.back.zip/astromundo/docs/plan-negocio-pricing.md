# Plan de negocio y pricing

## Planes para el astrólogo (suscripción a la plataforma)

| | **Gratis** | **Profesional** | **Estudio** |
|---|---|---|---|
| Precio | $0 | $25.000/mes | $65.000/mes |
| Cartas por mes | 5 | Ilimitadas | Ilimitadas |
| Mini sitio propio | No (marca de la plataforma) | Sí, subdominio propio | Sí + dominio propio |
| Interpretación con IA | Básica, sin plantillas propias | Completa, plantillas personalizables | Completa + entrenamiento de voz avanzado |
| Agenda y pagos online | No | Sí | Sí |
| Comisión por transacción | — | 4,5% | 2,5% |
| Usuarios / asistentes | 1 | 1 | hasta 5 |
| Reportes de práctica | No | Básicos | Avanzados (ocupación, retención, LTV por cliente) |

**Lógica del modelo**: el plan gratis no es "freemium para siempre" — sirve para que el astrólogo pruebe el motor de cálculo y la IA sin fricción, pero sin mini sitio ni cobros, así que naturalmente empuja a upgradear en cuanto quiere vender algo de verdad. El ingreso real de la plataforma combina **suscripción fija + comisión variable** — la comisión baja (4,5% → 2,5%) en el plan más caro es el incentivo típico de SaaS + marketplace para que los astrólogos con más volumen migren de plan.

## Unit economics — ejemplo con un astrólogo típico del plan Profesional

Supuestos: 15 cartas/mes, precio promedio $30.000 por servicio, 10 de esas 15 pagadas online a través de la plataforma (el resto puede ser presencial/efectivo).

- Ingreso por suscripción: $25.000
- Volumen procesado: 10 × $30.000 = $300.000
- Comisión (4,5%): $13.500
- **Ingreso total generado por ese astrólogo: ~$38.500/mes**

Con 200 astrólogos activos en el plan Profesional a este promedio: **~$7.700.000/mes** de ingreso recurrente antes de costos de infraestructura (cálculo astral es barato de correr; el costo variable más relevante es la API de IA para interpretación — conviene medir costo por interpretación generada y tenerlo como métrica de unit economics propia, separada de la suscripción).

## Costos variables a monitorear desde el día 1

- **Costo por interpretación IA**: tokens de entrada (carta calculada + plantilla) + tokens de salida (texto generado). Si un astrólogo regenera mucho un mismo bloque, ese costo sube sin que haya ingreso adicional — vale la pena poner un límite razonable de regeneraciones incluidas por plan y no comunicarlo como "ilimitado" sin control.
- **Comisión de pasarela de pago** (Mercado Pago cobra su propio %) — se resta antes de calcular la comisión neta de la plataforma, no encima.
- **WhatsApp Business API** (recordatorios) tiene costo por conversación iniciada — usar con criterio (recordatorio de turno sí, notificación de marketing no por este canal).

## Canales de adquisición (para los primeros astrólogos)

- **Comunidades de astrología ya existentes** (grupos de Instagram, cursos de formación astrológica) — el astrólogo recién recibido es el usuario con más fricción para empezar a cobrar y el que más valora una herramienta que lo haga ver profesional desde el turno 1
- **Programa de referidos entre astrólogos**: un mes gratis de Profesional por cada astrólogo referido que se suscribe — el boca a boca dentro de este nicho es fuerte porque se conocen entre sí (cursos, congresos, comunidades)
- **SEO de los mini sitios**: cada mini sitio público bien indexado es, en sí mismo, una pieza de marketing para la plataforma (aparece "hecho con [plataforma]" discreto en el plan gratis)

## Riesgo comercial más grande a validar primero

No es técnico — es si el astrólogo está dispuesto a **pagar una suscripción mensual fija** en un rubro donde hoy la mayoría cobra informal (transferencia, sin herramientas). Vale la pena arrancar con:
1. Entrevistas a 10-15 astrólogos reales sobre cómo gestionan hoy turnos y cobros
2. Un plan "fundador" con descuento fijo de por vida para los primeros 50 astrólogos, a cambio de feedback constante — reduce el riesgo de construir features que nadie termina pagando

## Roadmap de negocio (primeros 6 meses)

| Mes | Foco |
|---|---|
| 1–2 | MVP de cálculo + interpretación IA. Validar con 10 astrólogos "fundadores" sin cobrar todavía |
| 3 | Agregar mini sitio + agenda + pagos. Empezar a cobrar el plan Profesional con descuento fundador |
| 4 | CRM y alertas de tránsitos. Medir retención mensual (¿el astrólogo vuelve a generar cartas cada semana?) |
| 5–6 | Ajustar pricing con datos reales de uso, abrir plan Estudio, empezar canal de referidos activo |
